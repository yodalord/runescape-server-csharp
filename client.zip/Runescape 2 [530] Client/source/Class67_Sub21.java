/* Class67_Sub21 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub21 extends Class67
{
    public RSString aRSString_3173;
    public static int anInt3174 = 0;
    public static int anInt3175;
    public static int anInt3176;
    public static RSString aRSString_3177
	= Class134.method1914("Verbindung abgebrochen)3", (byte) 20);
    public static int anInt3178;
    public static int anInt3179;
    
    public static void method1275(int arg0, int arg1) {
	anInt3178++;
	Class67_Sub5_Sub3 class67_sub5_sub3
	    = Class103.method1558(arg1, false, 9);
	class67_sub5_sub3.method844(arg0);
    }
    
    public Class67_Sub21() {
	/* empty */
    }
    
    public Class67_Sub21(RSString arg0, int arg1) {
	aRSString_3173 = arg0;
    }
    
    public static void method1276(RSString arg0, byte arg1) {
	anInt3179++;
	int i = Class67_Sub5_Sub11_Sub2.method940(arg0, arg1 + -78);
	if (arg1 == 77 && i != -1)
	    Class67_Sub1_Sub32.method767(-5402,
					 (Class68.aClass72_1369.aShortArray1443
					  [i]),
					 (Class68.aClass72_1369.aShortArray1444
					  [i]));
    }
    
    public static void method1277(int arg0) {
	int i = 46 / ((44 - arg0) / 50);
	aRSString_3177 = null;
    }
    
    static {
	anInt3176 = 127;
	anInt3175 = 128;
    }
}
