import java.applet.Applet;

public class Class138
{
    public static void method1935(int arg0, String arg1, Applet arg2) {
    }
    
    public static Object method1936(int arg0, Applet arg1, String arg2)
	throws Throwable {
	if (arg0 != -11594)
	    return null;
	return null;
    }
}
