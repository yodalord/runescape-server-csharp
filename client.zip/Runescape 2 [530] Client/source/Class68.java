/* Class68 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class68
{
    public int anInt1350;
    public int anInt1351;
    public int anInt1352;
    public int anInt1353;
    public int anInt1354;
    public int anInt1355;
    public int anInt1356;
    public int anInt1357;
    public int anInt1358;
    public int anInt1359;
    public static Applet_Sub1 anApplet_Sub1_1360 = null;
    public static int anInt1361;
    public int anInt1362;
    public int anInt1363;
    public int anInt1364;
    public static RSString aRSString_1365
	= Class134.method1914(" steht bereits auf Ihrer Freunde)2Liste(Q",
			      (byte) 100);
    public static Class7[] aClass7Array1366;
    public int anInt1367;
    public int anInt1368;
    public static Class72 aClass72_1369;
    public int anInt1370;
    public static int anInt1371 = 0;
    public static int[][] anIntArrayArray1372;
    public static int anInt1373;
    public int anInt1374;
    public static int[] anIntArray1375 = new int[100];
    public int anInt1376;
    public static int anInt1377;
    public static boolean aBoolean1378 = false;
    
    public static Class67_Sub5_Sub19 method1320
	(int arg0, int arg1, boolean arg2, int arg3, byte arg4, int arg5) {
	anInt1377++;
	int i = arg3;
	int i_0_ = arg0 - (-(!arg2 ? 0 : 65536) - (arg1 << -1265864271)
			   - (arg5 << 405578355));
	int i_1_ = -15 / ((6 - arg4) / 57);
	long l = (long) i_0_ * 3849834839L + 3147483667L * (long) i;
	Class67_Sub5_Sub19 class67_sub5_sub19
	    = ((Class67_Sub5_Sub19)
	       Class96_Sub1.aClass136_3381.method1924(l, false));
	if (class67_sub5_sub19 != null)
	    return class67_sub5_sub19;
	Class26.aBoolean613 = false;
	class67_sub5_sub19 = Class65.method583(arg0, false, arg3, false, 120,
					       arg1, arg2, arg5);
	if (class67_sub5_sub19 != null && !Class26.aBoolean613)
	    Class96_Sub1.aClass136_3381.method1926(l, class67_sub5_sub19,
						   (byte) -71);
	return class67_sub5_sub19;
    }
    
    public static void method1321(int arg0) {
	anIntArray1375 = null;
	aClass7Array1366 = null;
	anIntArrayArray1372 = null;
	aRSString_1365 = null;
	if (arg0 != 25180)
	    anIntArray1375 = null;
	aClass72_1369 = null;
    }
    
    public static void method1322(int arg0, int arg1, byte arg2, int arg3,
				  int arg4, int arg5) {
	anInt1361++;
	int i = 111 % ((-16 - arg2) / 51);
	for (int i_2_ = arg1; i_2_ <= arg4; i_2_++)
	    Class67_Sub1_Sub11.method665(2, arg5,
					 (Class67_Sub29.anIntArrayArray3338
					  [i_2_]),
					 arg0, arg3);
    }
}
