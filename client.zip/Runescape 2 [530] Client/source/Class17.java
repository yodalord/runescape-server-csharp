public class Class17
{
    public static void method179(Object[] arg0, int arg1, Object[] arg2,
				 int arg3, int arg4) {
	if (arg0 == arg2) {
	    if (arg1 == arg3)
		return;
	    if (arg3 > arg1 && arg3 < arg1 + arg4) {
		arg4--;
		arg1 += arg4;
		arg3 += arg4;
		arg4 = arg1 - arg4;
		arg4 += 7;
		while (arg1 >= arg4) {
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		}
		arg4 -= 7;
		while (arg1 >= arg4)
		    arg2[arg3--] = arg0[arg1--];
		return;
	    }
	}
	arg4 += arg1;
	arg4 -= 7;
	while (arg1 < arg4) {
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	}
	arg4 += 7;
	while (arg1 < arg4)
	    arg2[arg3++] = arg0[arg1++];
    }
    
    public static void method180(int[] arg0, int arg1, int arg2) {
	arg2 = arg1 + arg2 - 7;
	while (arg1 < arg2) {
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	    arg0[arg1++] = 0;
	}
	arg2 += 7;
	while (arg1 < arg2)
	    arg0[arg1++] = 0;
    }
    
    public static void method181(int[] arg0, int arg1, int[] arg2, int arg3,
				 int arg4) {
	if (arg0 == arg2) {
	    if (arg1 == arg3)
		return;
	    if (arg3 > arg1 && arg3 < arg1 + arg4) {
		arg4--;
		arg1 += arg4;
		arg3 += arg4;
		arg4 = arg1 - arg4;
		arg4 += 7;
		while (arg1 >= arg4) {
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		}
		arg4 -= 7;
		while (arg1 >= arg4)
		    arg2[arg3--] = arg0[arg1--];
		return;
	    }
	}
	arg4 += arg1;
	arg4 -= 7;
	while (arg1 < arg4) {
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	}
	arg4 += 7;
	while (arg1 < arg4)
	    arg2[arg3++] = arg0[arg1++];
    }
    
    public static void method182(long[] arg0, int arg1, long[] arg2, int arg3,
				 int arg4) {
	if (arg0 == arg2) {
	    if (arg1 == arg3)
		return;
	    if (arg3 > arg1 && arg3 < arg1 + arg4) {
		arg4--;
		arg1 += arg4;
		arg3 += arg4;
		arg4 = arg1 - arg4;
		arg4 += 3;
		while (arg1 >= arg4) {
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		}
		arg4 -= 3;
		while (arg1 >= arg4)
		    arg2[arg3--] = arg0[arg1--];
		return;
	    }
	}
	arg4 += arg1;
	arg4 -= 3;
	while (arg1 < arg4) {
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	}
	arg4 += 3;
	while (arg1 < arg4)
	    arg2[arg3++] = arg0[arg1++];
    }
    
    public static void method183(short[] arg0, int arg1, short[] arg2,
				 int arg3, int arg4) {
	if (arg0 == arg2) {
	    if (arg1 == arg3)
		return;
	    if (arg3 > arg1 && arg3 < arg1 + arg4) {
		arg4--;
		arg1 += arg4;
		arg3 += arg4;
		arg4 = arg1 - arg4;
		arg4 += 7;
		while (arg1 >= arg4) {
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		}
		arg4 -= 7;
		while (arg1 >= arg4)
		    arg2[arg3--] = arg0[arg1--];
		return;
	    }
	}
	arg4 += arg1;
	arg4 -= 7;
	while (arg1 < arg4) {
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	}
	arg4 += 7;
	while (arg1 < arg4)
	    arg2[arg3++] = arg0[arg1++];
    }
    
    public static void method184(int[] arg0, int arg1, int arg2, int arg3) {
	arg2 = arg1 + arg2 - 7;
	while (arg1 < arg2) {
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	    arg0[arg1++] = arg3;
	}
	arg2 += 7;
	while (arg1 < arg2)
	    arg0[arg1++] = arg3;
    }
    
    public static void method185(byte[] arg0, int arg1, byte[] arg2, int arg3,
				 int arg4) {
	if (arg0 == arg2) {
	    if (arg1 == arg3)
		return;
	    if (arg3 > arg1 && arg3 < arg1 + arg4) {
		arg4--;
		arg1 += arg4;
		arg3 += arg4;
		arg4 = arg1 - arg4;
		arg4 += 7;
		while (arg1 >= arg4) {
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		    arg2[arg3--] = arg0[arg1--];
		}
		arg4 -= 7;
		while (arg1 >= arg4)
		    arg2[arg3--] = arg0[arg1--];
		return;
	    }
	}
	arg4 += arg1;
	arg4 -= 7;
	while (arg1 < arg4) {
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	    arg2[arg3++] = arg0[arg1++];
	}
	arg4 += 7;
	while (arg1 < arg4)
	    arg2[arg3++] = arg0[arg1++];
    }
}
