/* Class67_Sub5_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub5_Sub3 extends Class67_Sub5
{
    public static int anInt4484;
    public static int anInt4485;
    public static int anInt4486;
    public static int anInt4487;
    public static int anInt4488;
    public static int anInt4489 = 0;
    public static int[] anIntArray4490;
    public int anInt4491;
    public static int anInt4492;
    public static int anInt4493;
    public static int anInt4494 = 0;
    public int anInt4495;
    public static int anInt4496;
    public RSString aRSString_4497;
    public static RSString aRSString_4498;
    public static int anInt4499;
    public int anInt4500;
    public static boolean[] aBooleanArray4501;
    public static RSString aRSString_4502;
    
    public static RSString method841(int arg0) {
	anInt4493++;
	RSString RSString = Class69.aRSString_1382;
	if (Class23.anInt555 != 0)
	    RSString = Class130.aRSString_2408;
	RSString RSString_0_ = Class67_Sub5_Sub5.aRSString_4523;
	if (arg0 != -8969)
	    return null;
	if (Class101.aRSString_1991 != null)
	    RSString_0_
		= Class67_Sub1_Sub27.method744((new RSString[]
						{ (Class67_Sub11_Sub2
						   .aRSString_4860),
						  Class101.aRSString_1991 }),
					       arg0 ^ 0x2361);
	return (Class67_Sub1_Sub27.method744
		((new RSString[]
		  { Class73.aRSString_1452, RSString, Class67_Sub6.aRSString_2876,
		    InputStream_Sub1.method47(Class131_Sub3.anInt3603, true),
		    Class67_Sub1_Sub23.aRSString_4188,
		    InputStream_Sub1.method47(anInt4489, true), RSString_0_,
		    Class117.aRSString_2218 }),
		 arg0 ^ 0x2379));
    }
    
    public int method842(int arg0) {
	int i = -92 / ((-26 - arg0) / 59);
	anInt4496++;
	return (int) (0xffL & aLong1344 >>> -168909728);
    }
    
    public int method843(byte arg0) {
	if (arg0 <= 122)
	    return -123;
	anInt4499++;
	return (int) aLong1344;
    }
    
    public void method844(int arg0) {
	if (arg0 == 0) {
	    aLong2863 = (Class39.method337(arg0 ^ 0x4cbc) - -500L
			 | aLong2863 & ~0x7fffffffffffffffL);
	    Class11.aClass120_415.method1663(this, arg0 + -225);
	    anInt4488++;
	}
    }
    
    public long method845(byte arg0) {
	if (arg0 != -34)
	    method843((byte) 107);
	anInt4484++;
	return 0x7fffffffffffffffL & aLong2863;
    }
    
    public void method846(boolean arg0) {
	aLong2863 |= ~0x7fffffffffffffffL;
	if (arg0 != true)
	    anInt4494 = -4;
	if ((method845((byte) -34) ^ 0xffffffffffffffffL) == -1L)
	    Class90.aClass120_1843.method1663(this, -225);
	anInt4485++;
    }
    
    public static void method847(byte arg0) {
	aRSString_4502 = null;
	if (arg0 >= -16)
	    method848(-43, 97, -52, 44, (byte) 3);
	aRSString_4498 = null;
	aBooleanArray4501 = null;
	anIntArray4490 = null;
    }
    
    public static void method848(int arg0, int arg1, int arg2, int arg3,
				 byte arg4) {
	if (arg4 != -102)
	    method848(-85, 69, -76, -15, (byte) -3);
	Class67_Sub5_Sub3 class67_sub5_sub3
	    = Class103.method1558(arg1, false, 10);
	anInt4486++;
	class67_sub5_sub3.method846(true);
	class67_sub5_sub3.anInt4491 = arg3;
	class67_sub5_sub3.anInt4500 = arg2;
	class67_sub5_sub3.anInt4495 = arg0;
    }
    
    public Class67_Sub5_Sub3(int arg0, int arg1) {
	aLong1344 = (long) arg0 << 279338016 | (long) arg1;
    }
    
    static {
	anIntArray4490 = new int[2];
	aBooleanArray4501 = new boolean[100];
	aRSString_4502 = Class134.method1914("Close", (byte) 54);
	aRSString_4498 = aRSString_4502;
    }
}
