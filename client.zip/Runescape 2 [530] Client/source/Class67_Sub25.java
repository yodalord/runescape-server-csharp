/* Class67_Sub25 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub25 extends Class67
{
    public static RSString aRSString_3246
	= Class134.method1914("::fps ", (byte) 110);
    public byte aByte3247;
    public static int anInt3248;
    public RSString aRSString_3249;
    public static RSString aRSString_3250
	= Class134.method1914("(U (X", (byte) 21);
    public static Class50 aClass50_3251;
    public RSString aRSString_3252;
    public static int anInt3253 = 2;
    public static RSString aRSString_3254
	= Class134.method1914("<img=0>", (byte) 16);
    public int anInt3255;
    
    public static void method1292(int arg0, boolean arg1) {
	anInt3248++;
	Class67_Sub5_Sub3 class67_sub5_sub3
	    = Class103.method1558(arg0, !arg1, 4);
	if (arg1 != true)
	    aRSString_3246 = null;
	class67_sub5_sub3.method844(0);
    }
    
    public static void method1293(int arg0) {
	aClass50_3251 = null;
	aRSString_3250 = null;
	aRSString_3254 = null;
	aRSString_3246 = null;
	if (arg0 != 2)
	    method1293(36);
    }
    
    static {
	aClass50_3251 = new Class50();
    }
}
