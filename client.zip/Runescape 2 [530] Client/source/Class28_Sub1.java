import java.awt.Component;

public class Class28_Sub1 extends Class28
{
    public static Interface1 anInterface1_2755;
    public int anInt2756;
    
    public void method272(Component arg0) throws Exception {
	anInterface1_2755.method6(Class25.aBoolean605, -41, arg0,
				  Class89.anInt1833);
    }
    
    public void method263() {
	anInterface1_2755.method4(48, anInt2756);
    }
    
    public void method269(int arg0) throws Exception {
	if (arg0 > 32768)
	    throw new IllegalArgumentException();
	anInterface1_2755.method3((byte) -84, anInt2756, arg0);
    }
    
    public void method275() {
	anInterface1_2755.method5(-128, anInt2756);
    }
    
    public int method262() {
	return anInterface1_2755.method2(18576, anInt2756);
    }
    
    public void method273() {
	anInterface1_2755.method1(anInt2756, anIntArray651);
    }
    
    public Class28_Sub1(SignLink arg0, int arg1) {
	anInterface1_2755 = arg0.method406(-106);
	anInt2756 = arg1;
    }
    
    public static void method276() {
	anInterface1_2755 = null;
    }
}
