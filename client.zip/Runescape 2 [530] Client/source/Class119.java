public abstract class Class119
{
    public static int anInt2241;
    public int anInt2242;
    public int anInt2243;
    public static RSString aRSString_2244;
    public static int anInt2245;
    public static RSString aRSString_2246
	= Class134.method1914("Choose Option", (byte) 82);
    public static RSString aRSString_2247;
    public static long aLong2248;
    public static RSString aRSString_2249;
    public int anInt2250;
    public static RSString aRSString_2251;
    public int anInt2252;
    public static RSString aRSString_2253;
    public int anInt2254;
    public int anInt2255;
    public static RSString aRSString_2256;
    public static RSString aRSString_2257;
    public static RSString aRSString_2258;
    public static RSString aRSString_2259;
    public static int anInt2260;
    public static int anInt2261;
    public static int anInt2262;
    public static int anInt2263;
    public static int anInt2264;
    
    public static void method1640(int arg0) {
	aRSString_2244 = null;
	aRSString_2256 = null;
	aRSString_2258 = null;
	aRSString_2246 = null;
	aRSString_2259 = null;
	aRSString_2251 = null;
	if (arg0 == 0) {
	    aRSString_2247 = null;
	    aRSString_2249 = null;
	    aRSString_2253 = null;
	    aRSString_2257 = null;
	}
    }
    
    public abstract void method1641(int i, int i_0_);
    
    public abstract void method1642(int i, int i_1_, int i_2_);
    
    public static void method1643(int arg0, int arg1, int arg2, int arg3,
				  int arg4, int arg5, int arg6, int arg7,
				  byte arg8, int arg9) {
	try {
	    if (arg8 > 120) {
		anInt2262++;
		if ((arg1 ^ 0xffffffff) <= (Class139.anInt2533 ^ 0xffffffff)
		    && arg1 <= Class126_Sub1.anInt3423
		    && (arg6 ^ 0xffffffff) <= (Class139.anInt2533 ^ 0xffffffff)
		    && (arg6 ^ 0xffffffff) >= (Class126_Sub1.anInt3423
					       ^ 0xffffffff)
		    && (arg9 ^ 0xffffffff) <= (Class139.anInt2533 ^ 0xffffffff)
		    && Class126_Sub1.anInt3423 >= arg9
		    && arg2 >= Class139.anInt2533
		    && (arg2 ^ 0xffffffff) >= (Class126_Sub1.anInt3423
					       ^ 0xffffffff)
		    && arg7 >= Class55_Sub2.anInt2801
		    && ((OutputStream_Sub1.anInt87 ^ 0xffffffff)
			<= (arg7 ^ 0xffffffff))
		    && Class55_Sub2.anInt2801 <= arg0
		    && OutputStream_Sub1.anInt87 >= arg0
		    && (Class55_Sub2.anInt2801 ^ 0xffffffff) >= (arg5
								 ^ 0xffffffff)
		    && ((OutputStream_Sub1.anInt87 ^ 0xffffffff)
			<= (arg5 ^ 0xffffffff))
		    && Class55_Sub2.anInt2801 <= arg4
		    && (arg4 ^ 0xffffffff) >= (OutputStream_Sub1.anInt87
					       ^ 0xffffffff))
		    Class67_Sub1_Sub36.method787(arg4, arg9, arg5, arg2,
						 (byte) -121, arg1, arg7, arg6,
						 arg3, arg0);
		else
		    Class67_Sub5_Sub6.method870(arg9, arg0, arg2, arg5, arg7,
						arg3, 3, arg6, arg4, arg1);
	    }
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       ("si.B(" + arg0 + ',' + arg1
						+ ',' + arg2 + ',' + arg3 + ','
						+ arg4 + ',' + arg5 + ','
						+ arg6 + ',' + arg7 + ','
						+ arg8 + ',' + arg9 + ')'));
	}
    }
    
    public static void method1644(byte arg0, int arg1) {
	try {
	    anInt2263++;
	    Class18.aClass136_2730.method1920(arg1, 90);
	    int i = 1 / ((arg0 - 47) / 52);
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       ("si.D(" + arg0 + ',' + arg1
						+ ')'));
	}
    }
    
    public static void method1645(int arg0) {
	try {
	    anInt2264++;
	    if ((Class55_Sub2.anInt2800 ^ 0xffffffff) < -1)
		Class131_Sub4.method1819(127);
	    else {
		Class86.aClass117_1764 = Class41.aClass117_867;
		Class41.aClass117_867 = null;
		if (arg0 >= -35)
		    aRSString_2249 = null;
		Class40.method348(-11461, 40);
	    }
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       "si.E(" + arg0 + ')');
	}
    }
    
    public static void method1646(byte arg0, Class9 arg1, Class9 arg2) {
	do {
	    try {
		anInt2241++;
		Class84.aClass67_Sub5_Sub10_1692
		    = Class116.method1622(arg1, Class67_Sub5_Sub3.anInt4492, 0,
					  0, arg2);
		PacketParser.aClass67_Sub5_Sub10_Sub1_2108
		    = ((Class67_Sub5_Sub10_Sub1)
		       Class84.aClass67_Sub5_Sub10_1692);
		Class143.aClass67_Sub5_Sub10_2583
		    = Class116.method1622(arg1, Class67_Sub1_Sub36.anInt4367,
					  0, 0, arg2);
		Class130.aClass67_Sub5_Sub10_2404
		    = Class116.method1622(arg1, Class15.anInt458, 0, 0, arg2);
		if (arg0 >= 83)
		    break;
		method1643(0, -105, -48, -69, 26, -101, 11, -55, (byte) -30,
			   -119);
	    } catch (RuntimeException runtimeexception) {
		throw Class67_Sub1_Sub21.method718(runtimeexception,
						   ("si.G(" + arg0 + ','
						    + (arg1 != null ? "{...}"
						       : "null")
						    + ','
						    + (arg2 != null ? "{...}"
						       : "null")
						    + ')'));
	    }
	    break;
	} while (false);
    }
    
    static {
	anInt2245 = 0;
	aRSString_2257 = aRSString_2246;
	aRSString_2251 = Class134.method1914("K", (byte) 123);
	anInt2261 = -16 + (int) (33.0 * Math.random());
	aRSString_2247 = Class134.method1914("Face here", (byte) 4);
	anInt2260 = -1;
	aRSString_2249 = Class134.method1914("comp-Btence ", (byte) 17);
	aRSString_2253 = aRSString_2247;
	aRSString_2259
	    = Class134.method1914("Speicher wird zugewiesen)3", (byte) 72);
	aRSString_2258 = Class134.method1914("scroll:", (byte) 54);
	aRSString_2244 = aRSString_2258;
	aRSString_2256 = aRSString_2258;
    }
}
