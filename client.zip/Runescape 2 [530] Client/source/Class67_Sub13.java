/* Class67_Sub13 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class67_Sub13 extends Class67
{
    public int anInt3045;
}
