/* Class67_Sub5_Sub18 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub5_Sub18 extends Class67_Sub5
{
    public static int anInt4802;
    public static int[] anIntArray4803
	= { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
	    19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
	    36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
	    53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 73, 74, 76, 78,
	    83, 84, 85, 86, 91, 92, 93, 94, 95, 97, 103, 104, 105, 106, 107,
	    108, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 124, 125,
	    133, 134, 136, 138, 143, 144, 145, 146, 151, 152, 153, 154, 155,
	    157, 163, 164, 165, 166, 168, 169, 174, 175, 176, 177, 180, 181,
	    182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194,
	    195, 196, 197, 97, 199, 200, 201, 202, 203, 204, 205, 206, 207,
	    208, 209, 210, 211, 212, 213, 157, 215, 216, 117, 218, 219, 220,
	    221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233,
	    234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246,
	    247, 248, 249, 66, 66, 66, 66, 66, 66, 65, 75, 79, 79, 79, 79, 87,
	    87, 87, 87, 77, 96, 98, 98, 98, 98, 98, 250, 251, 109, 109, 109,
	    109, 117, 252, 167, 126, 126, 126, 126, 126, 126, 125, 135, 139,
	    139, 139, 139, 147, 147, 147, 147, 137, 156, 158, 158, 158, 158,
	    158, 253, 254, 170, 170, 170, 170, 178, 255, 178 };
    public static int anInt4804 = 0;
    public static int[] anIntArray4805;
    public static int anInt4806;
    public Class131_Sub3 aClass131_Sub3_4807;
    public static int anInt4808;
    public static int anInt4809;
    public static Class131_Sub7_Sub2[] aClass131_Sub7_Sub2Array4810
	= new Class131_Sub7_Sub2[2048];
    public static int anInt4811 = 1;
    
    public static Class67_Sub5_Sub10 method997(byte[] arg0, int arg1) {
	anInt4809++;
	if (arg0 == null)
	    return null;
	Class67_Sub5_Sub10_Sub1 class67_sub5_sub10_sub1
	    = new Class67_Sub5_Sub10_Sub1(arg0, Class67_Sub23.anIntArray3201,
					  Class67_Sub6.anIntArray2870,
					  Class55_Sub3.anIntArray2810,
					  Class67_Sub5_Sub4.anIntArray4510,
					  (Class67_Sub1_Sub35
					   .aByteArrayArray4357));
	if (arg1 != 174)
	    anInt4811 = -7;
	Class67_Sub5_Sub11.method937(false);
	return class67_sub5_sub10_sub1;
    }
    
    public static void method998(int arg0, int arg1) {
	synchronized (Class6.aClass133_154) {
	    Class67_Sub1_Sub12.anInt4014 = arg0;
	}
	if (arg1 <= 61)
	    method998(-77, 56);
	anInt4802++;
    }
    
    public static void method999(int arg0) {
	anIntArray4803 = null;
	anIntArray4805 = null;
	aClass131_Sub7_Sub2Array4810 = null;
	if (arg0 < 104)
	    method998(60, 62);
    }
    
    public Class67_Sub5_Sub18(Class131_Sub3 arg0) {
	aClass131_Sub3_4807 = arg0;
    }
}
