/* Class88 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class88
{
    public int anInt1815;
    public Class131 aClass131_1816;
    public static int anInt1817 = 5063219;
    public int anInt1818;
    public long aLong1819;
    public Class131 aClass131_1820;
    public static byte aByte1821;
    public static int[] anIntArray1822 = new int[500];
    public int anInt1823;
    public static RSString aRSString_1824
	= Class134.method1914(":trade:", (byte) 58);
    public Class131 aClass131_1825;
    public int anInt1826;
    public static int pingsSent;
    public static long serverSessionKey = 0L;
    
    public static void method1466(byte arg0) {
	anIntArray1822 = null;
	aRSString_1824 = null;
	if (arg0 != -36)
	    aRSString_1824 = null;
    }
}
