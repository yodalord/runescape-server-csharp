/* Class67_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class67_Sub2 extends Class67
{
    public int anInt2841;
    
    public abstract int method813(Class67_Sub11_Sub1 class67_sub11_sub1);
    
    public abstract void method814();
}
