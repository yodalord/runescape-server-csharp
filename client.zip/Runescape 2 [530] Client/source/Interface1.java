/* Interface1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Component;

public interface Interface1
{
    public void method1(int i, int[] is);
    
    public int method2(int i, int i_0_);
    
    public void method3(byte i, int i_1_, int i_2_) throws Exception;
    
    public void method4(int i, int i_3_);
    
    public void method5(int i, int i_4_);
    
    public void method6(boolean bool, int i, Component component, int i_5_)
	throws Exception;
}
