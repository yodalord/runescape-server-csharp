/* Class67_Sub14 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub14 extends Class67
{
    public static int anInt3046;
    public static int anInt3047 = 0;
    public static int anInt3048;
    public static RSString aRSString_3049;
    public static int anInt3050;
    public static RSString aRSString_3051;
    public static int anInt3052;
    public int anInt3053;
    public static int anInt3054;
    public static int anInt3055;
    public static int anInt3056;
    public static RSString aRSString_3057
	= Class134.method1914("Chargement des interfaces )2 ", (byte) 31);
    public static int anInt3058;
    public static int anInt3059;
    public int anInt3060;
    public static int anInt3061;
    public static RSString aRSString_3062;
    public static int anInt3063;
    public static int anInt3064;
    public static int anInt3065;
    public static int anInt3066;
    
    public static void method1223(boolean arg0) {
	anInt3065++;
	if (arg0 != true)
	    method1233(-127, (byte) -25);
	for (Class67_Sub6 class67_sub6 = (Class67_Sub6) Class67_Sub1_Sub39
							    .aClass50_4441
							    .method445(0);
	     class67_sub6 != null;
	     class67_sub6 = ((Class67_Sub6)
			     Class67_Sub1_Sub39.aClass50_4441.method432(0))) {
	    if (class67_sub6.anInt2869 == -1) {
		class67_sub6.anInt2883 = 0;
		Class55_Sub2_Sub1.method473(class67_sub6, 0);
	    } else
		class67_sub6.method606((byte) -118);
	}
    }
    
    public static void method1224(int arg0) {
	aRSString_3049 = null;
	aRSString_3051 = null;
	aRSString_3062 = null;
	if (arg0 == 4)
	    aRSString_3057 = null;
    }
    
    public int method1225(int arg0) {
	anInt3048++;
	if (arg0 != -1)
	    anInt3064 = -29;
	return Class137.method1933(anInt3060, (byte) -32);
    }
    
    public boolean method1226(int arg0) {
	anInt3052++;
	if (arg0 != 3867171)
	    method1231(-72);
	if ((0x1 & anInt3060 >> 1754248607 ^ 0xffffffff) == -1)
	    return false;
	return true;
    }
    
    public boolean method1227(int arg0) {
	if (arg0 != -23)
	    aRSString_3062 = null;
	anInt3059++;
	if (((anInt3060 & 0x1d9a9815) >> -1451594596 ^ 0xffffffff) == -1)
	    return false;
	return true;
    }
    
    public int method1228(int arg0) {
	if (arg0 != -30954)
	    method1235(98);
	anInt3058++;
	return 0x7 & anInt3060 >> 2019495794;
    }
    
    public boolean method1229(byte arg0, int arg1) {
	if (arg0 > -67)
	    method1231(51);
	anInt3061++;
	if ((anInt3060 >> arg1 + 1 & 0x1) == 0)
	    return false;
	return true;
    }
    
    public boolean method1230(int arg0) {
	if (arg0 != 3867171)
	    method1235(106);
	anInt3055++;
	if ((anInt3060 >> -965599778 & 0x1 ^ 0xffffffff) == -1)
	    return false;
	return true;
    }
    
    public boolean method1231(int arg0) {
	if (arg0 != 12928)
	    return true;
	anInt3056++;
	if ((0x1 & anInt3060 >> -1104608106) == 0)
	    return false;
	return true;
    }
    
    public boolean method1232(byte arg0) {
	anInt3046++;
	int i = -111 % ((arg0 - 24) / 44);
	if ((anInt3060 & 0x1 ^ 0xffffffff) == -1)
	    return false;
	return true;
    }
    
    public static int method1233(int arg0, byte arg1) {
	if (arg1 <= 32)
	    anInt3047 = -126;
	anInt3054++;
	if (Class41.aClass117_867 != null) {
	    Class41.aClass117_867.method1632((byte) -112);
	    Class41.aClass117_867 = null;
	}
	Class108.anInt2075++;
	if (Class108.anInt2075 > 4) {
	    Class140.anInt2549 = 0;
	    Class108.anInt2075 = 0;
	    return arg0;
	}
	Class140.anInt2549 = 0;
	if ((Class123.anInt2319 ^ 0xffffffff)
	    == (Class7.anInt241 ^ 0xffffffff))
	    Class7.anInt241 = Class13.anInt431;
	else
	    Class7.anInt241 = Class123.anInt2319;
	return -1;
    }
    
    public Class67_Sub14(int arg0, int arg1) {
	anInt3053 = arg1;
	anInt3060 = arg0;
    }
    
    public boolean method1234(byte arg0) {
	anInt3066++;
	int i = -106 / ((-25 - arg0) / 47);
	if ((anInt3060 >> 2135077725 & 0x1 ^ 0xffffffff) == -1)
	    return false;
	return true;
    }
    
    public boolean method1235(int arg0) {
	anInt3050++;
	if (arg0 != 0)
	    return true;
	if ((anInt3060 & 0x3b0223) >> 1108538805 == 0)
	    return false;
	return true;
    }
    
    public static void method1236(int arg0, Class9 arg1) {
	Class67_Sub1_Sub7.aClass9_3909 = arg1;
	anInt3063++;
	if (arg0 <= 88)
	    aRSString_3057 = null;
    }
    
    static {
	aRSString_3051 = Class134.method1914("wave:", (byte) 120);
	aRSString_3049 = aRSString_3051;
	aRSString_3062 = aRSString_3051;
    }
}
