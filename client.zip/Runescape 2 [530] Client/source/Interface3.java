/* Interface3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface3
{
    public boolean method7(int i, int i_0_);
    
    public boolean method8(int i, int i_1_);
    
    public int[] method9(int i, int i_2_);
    
    public boolean method10(int i, byte i_3_);
    
    public int[] method11(int i, float f, int i_4_);
    
    public int method12(byte i, int i_5_);
    
    public boolean method13(int i, int i_6_);
}
