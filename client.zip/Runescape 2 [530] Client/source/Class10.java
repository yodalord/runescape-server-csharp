/* Class10 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class10
{
    public static int anInt396 = 0;
    public static int anInt397;
    public static int anInt398;
    public static Class50 aClass50_399 = new Class50();
    public static int anInt400;
    public static Class54 aClass54_401;
    public static Class9 aClass9_402;
    public static int[] anIntArray403 = new int[1000];
    public static RSString aRSString_404
	= Class134.method1914("brillant2:", (byte) 117);
    
    public static RSString method139(byte arg0, int arg1) {
	anInt398++;
	if (arg0 > -89)
	    return null;
	RSString RSString = new RSString();
	RSString.anInt2629 = 0;
	RSString.aByteArray2653 = new byte[arg1];
	return RSString;
    }
    
    public static void method140(int arg0) {
	if (arg0 != 25548)
	    method139((byte) -55, 102);
	aClass54_401 = null;
	aClass50_399 = null;
	aClass9_402 = null;
	anIntArray403 = null;
	aRSString_404 = null;
    }
}
