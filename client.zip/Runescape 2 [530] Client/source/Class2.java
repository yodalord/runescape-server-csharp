public class Class2
{
    public static int anInt105;
    public static RSString aRSString_106
	= Class134.method1914(" <col=ffff00>", (byte) 110);
    public static int anInt107;
    public static Class9 aClass9_108;
    public static int anInt109;
    public static RSString aRSString_110
	= Class134.method1914("voudrait faire un -Bchange avec vous)3",
			      (byte) 63);
    public static RSString aRSString_111;
    public static int anInt112 = 0;
    
    public static int method66(byte arg0, int arg1) {
	anInt107++;
	if (arg1 != 255)
	    return 1;
	return 0xff & arg0;
    }
    
    public static void method67(int arg0) {
	aRSString_106 = null;
	if (arg0 != -1)
	    method67(111);
	aRSString_111 = null;
	aRSString_110 = null;
	aClass9_108 = null;
    }
    
    static {
	aRSString_111
	    = Class134.method1914("Musik)2Engine vorbereitet)3", (byte) 79);
	anInt109 = -1;
    }
}
