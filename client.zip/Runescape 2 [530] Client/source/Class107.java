/* Class107 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class107
{
    public static RSString aRSString_2067;
    public static Class9 aClass9_2068;
    public static int anInt2069 = -1;
    public static int anInt2070;
    public static boolean aBoolean2071;
    public static Class67_Sub5_Sub7[] aClass67_Sub5_Sub7Array2072;
    public static RSString aRSString_2073;
    public static boolean[] aBooleanArray2074;
    
    public static void method1572(byte arg0) {
	aRSString_2067 = null;
	aClass9_2068 = null;
	if (arg0 <= -48) {
	    aRSString_2073 = null;
	    aClass67_Sub5_Sub7Array2072 = null;
	    aBooleanArray2074 = null;
	}
    }
    
    static {
	aRSString_2067 = Class134.method1914("Hierhin gehen", (byte) 65);
	aBoolean2071 = false;
	aClass67_Sub5_Sub7Array2072 = new Class67_Sub5_Sub7[14];
	aRSString_2073
	    = Class134.method1914("Chargement des fichiers config )2 ",
				  (byte) 12);
	aBooleanArray2074 = new boolean[5];
    }
}
