/* Class67_Sub1_Sub30 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub1_Sub30 extends Class67_Sub1
{
    public static int anInt4272 = 0;
    public static int anInt4273;
    public static RSString aRSString_4274
	= Class134.method1914(" steht bereits auf Ihrer Ignorieren)2Liste(Q",
			      (byte) 19);
    public static RSString aRSString_4275
	= Class134.method1914("settings", (byte) 74);
    public static int anInt4276;
    public static int anInt4277;
    public static int anInt4278;
    
    public int[] method611(int arg0, byte arg1) {
	int[] is = aClass144_2836.method1961(arg0, true);
	if (arg1 != 55)
	    aRSString_4275 = null;
	if (aClass144_2836.aBoolean2607) {
	    int i = Class19.anIntArray490[arg0];
	    for (int i_0_ = 0;
		 ((i_0_ ^ 0xffffffff)
		  > (Class67_Sub5_Sub7.anInt4569 ^ 0xffffffff));
		 i_0_++)
		is[i_0_] = method756(Class67_Sub1_Sub35.anIntArray4344[i_0_],
				     57, i) % 4096;
	}
	anInt4277++;
	return is;
    }
    
    public static void method755(int arg0) {
	Class103.aRSString_2020 = Class67_Sub28.aRSString_3316;
	Class67_Sub30.aRSString_3346 = Class67_Sub28.aRSString_3325;
	Class67_Sub1_Sub37.aRSString_4397 = Class55.aRSString_1087;
	Class119.aRSString_2257 = Class126.aRSString_2352;
	Class28.aRSString_653 = Class67_Sub5_Sub4_Sub1.aRSString_5120;
	Class119.aRSString_2253 = Class67_Sub5_Sub4_Sub2.aRSString_5131;
	Class67_Sub1_Sub12.aRSString_4000 = Class136.aRSString_2482;
	Class67_Sub5_Sub1.aRSString_4459 = Class67_Sub1_Sub25.aRSString_4227;
	Class74.aRSString_1487 = Class67_Sub1_Sub24.aRSString_4214;
	Stream.aRSString_2901 = Class67_Sub5_Sub15.aRSString_4753;
	Class119.aRSString_2244 = Class67_Sub30.aRSString_3355;
	Class122.aRSString_2311 = Class129.aRSString_2399;
	Class67_Sub1_Sub26.aRSString_4230 = Class140.aRSString_2553;
	Class67_Sub5_Sub19.aRSString_4824 = Class37.aRSString_802;
	Class67_Sub5_Sub12.aRSString_4687 = Class36.aRSString_766;
	Class53.aRSString_1063 = PacketParser.aRSString_2104;
	Class67_Sub1_Sub36.aRSString_4378 = Class67_Sub1_Sub9.aRSString_3931;
	Class96_Sub1.aRSString_3379 = Class8.aRSString_344;
	Class67_Sub3.aRSString_2854 = Class119.aRSString_2251;
	Class81.aRSString_1651 = Class19.aRSString_484;
	Class129.aRSString_2396 = OutputStream_Sub1.aRSString_94;
	Class67_Sub1_Sub4.aRSString_3864 = Class67_Sub5_Sub2.aRSString_4476;
	Class67_Sub5_Sub14.aRSString_4747 = Class67_Sub12.aRSString_3044;
	Class76.aRSString_1544 = Class27.aRSString_640;
	Class67.aRSString_1338 = Class98.aRSString_1952;
	Class56.aRSString_1095 = Class120.aRSString_2290;
	Class67_Sub5_Sub16.aRSString_4781 = Class139.aRSString_2540;
	Class67_Sub1_Sub37.aRSString_4393 = Class132.aRSString_2436;
	Class67_Sub1_Sub16_Sub1.aRSString_5096
	    = Class67_Sub5_Sub11_Sub2.aRSString_5146;
	Class27.aRSString_625 = Class87.aRSString_1811;
	Class139.aRSString_2532 = Class118.aRSString_2236;
	Class67.aRSString_1345 = Class117.aRSString_2207;
	Class67_Sub28.aRSString_3322 = Class67_Sub5_Sub13.aRSString_4708;
	Class144.aRSString_2605 = Class67_Sub16.aRSString_3088;
	Class78.aRSString_1608 = Class87.aRSString_1807;
	Class105.aRSString_2043 = Class142.aRSString_2574;
	Class15.aRSString_463 = Class67_Sub27.aRSString_3298;
	Class123.aRSString_2314 = Class49.aRSString_1002;
	Class85.aRSString_1726 = Class90.aRSString_1852;
	Login.aRSString_1619 = Class67_Sub1_Sub9.aRSString_3944;
	Class91.aRSString_1856 = Class16.aRSString_481;
	Class67_Sub5_Sub3.aRSString_4498 = Class67_Sub1_Sub1.aRSString_3823;
	Class66.aRSString_1327 = RSString.aRSString_2680;
	client.aRSString_2742 = Class2.aRSString_110;
	Class67_Sub5_Sub4_Sub1.aRSString_5121 = Class129.aRSString_2393;
	Class131_Sub5.aRSString_3654 = Class67_Sub14.aRSString_3057;
	Class67_Sub6.aRSString_2893 = Class67_Sub30.aRSString_3357;
	PacketParser.aRSString_2111 = Class137.aRSString_2517;
	Class92.aRSString_1878 = Class107.aRSString_2073;
	Class67_Sub5_Sub2.aRSString_4469 = Class95.aRSString_1901;
	Class133.aRSString_2455 = Class67_Sub5_Sub9.aRSString_4619;
	Class67_Sub27.aRSString_3311 = Class44.aRSString_925;
	Class27.aRSString_631 = Class13.aRSString_428;
	Class67_Sub3.aRSString_2851 = Class119.aRSString_2251;
	Class53.aRSString_1064 = Class67_Sub5_Sub17.aRSString_4790;
	Class92.aRSString_1866 = Class32.aRSString_722;
	Class67_Sub5_Sub19.aRSString_4821 = Class67_Sub1_Sub35.aRSString_4354;
	Class55_Sub3_Sub1.aRSString_3809 = Class67_Sub5_Sub15.aRSString_4756;
	Class130.aRSString_2419 = Class67_Sub5_Sub4.aRSString_4505;
	Class136.aRSString_2491 = Class61.aRSString_1147;
	Class75.aRSString_2695 = Class67_Sub1_Sub35.aRSString_4342;
	Class67.aRSString_1343 = Class118.aRSString_2230;
	Class67_Sub1_Sub16.aRSString_4082 = Class56.aRSString_1102;
	Class126_Sub4.aRSString_3472 = Class117.aRSString_2222;
	Class67_Sub5_Sub12.aRSString_4702 = Class36.aRSString_766;
	anInt4278++;
	Class99_Sub1.aRSString_3387 = Class119.aRSString_2249;
	Class87.aRSString_1803 = Class13.aRSString_435;
	Class67_Sub24.aRSString_3239 = Class126_Sub3.aRSString_3455;
	Class4.aRSString_130 = Class85.aRSString_1723;
	Class58.aRSString_1116 = Class131_Sub3.aRSString_3608;
	Class30.aRSString_701 = Class10.aRSString_404;
	Class67_Sub9.aRSString_2974 = Class116.aRSString_2200;
	Class137.aRSString_2516 = Class67_Sub26.aRSString_3269;
	Class140.aRSString_2548 = Class118.aRSString_2233;
	Class67_Sub24.aRSString_3244 = Class90.aRSString_1845;
	Class131_Sub5.aRSString_3657 = Class81.aRSString_1657;
	int i = 75 / ((arg0 - 5) / 63);
	Class67_Sub22.aRSString_3182 = Class67_Sub5_Sub4_Sub1.aRSString_5119;
	Class89.aRSString_1838 = Class16.aRSString_465;
	Class72.aRSString_1442 = Class41.aRSString_864;
	Class67_Sub5_Sub14.aRSString_4740 = Class23.aRSString_557;
	Class67_Sub1_Sub10.aRSString_3970 = Class18.aRSString_2728;
	Class67_Sub5_Sub13.aRSString_4707 = Class32.aRSString_713;
	Class67_Sub1_Sub32.aRSString_4298 = Class63.aRSString_1166;
	Applet_Sub1.aRSString_20 = Class67_Sub5_Sub13.aRSString_4717;
	Class67_Sub28.aRSString_3327 = Class67_Sub5_Sub13.aRSString_4708;
	Class67_Sub1_Sub8.aRSString_3927 = Class67_Sub1_Sub16.aRSString_4070;
	Class67_Sub14.aRSString_3062 = Class67_Sub6.aRSString_2875;
	Class34.aRSString_744 = Class22.aRSString_532;
	Class67_Sub1_Sub3.aRSString_3849 = InputStream_Sub1.aRSString_79;
	Login.aRSString_1615 = Class67_Sub5_Sub12.aRSString_4685;
    }
    
    public int method756(int arg0, int arg1, int arg2) {
	anInt4276++;
	int i = arg1 * arg2 + arg0;
	i = i << 1537423425 ^ i;
	return (-((0x7fffffff & 1376312589 + (789221 + i * (i * 15731)) * i)
		  / 262144)
		+ 4096);
    }
    
    public Class67_Sub1_Sub30() {
	super(0, true);
    }
    
    public static boolean method757(int arg0, byte arg1) {
	Class67_Sub5_Sub4_Sub2.aBoolean5135 = true;
	Class66.anInt1326 = 0xffff & arg0 + 1;
	anInt4273++;
	if (arg1 != -128)
	    method758((byte) 22);
	return true;
    }
    
    public static void method758(byte arg0) {
	int i = 103 / ((arg0 - 82) / 36);
	aRSString_4275 = null;
	aRSString_4274 = null;
    }
}
