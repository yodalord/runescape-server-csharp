/* Class67_Sub11_Sub4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub11_Sub4 extends Class67_Sub11
{
    public static int anInt4881;
    public int[] anIntArray4882;
    public static int anInt4883;
    public int[] anIntArray4884 = new int[16];
    public static int anInt4885;
    public int[] anIntArray4886 = new int[16];
    public static int anInt4887;
    public static int anInt4888 = 0;
    public static int anInt4889;
    public int[] anIntArray4890;
    public static int anInt4891;
    public static int anInt4892;
    public static int anInt4893;
    public static int anInt4894;
    public static int anInt4895;
    public static int anInt4896;
    public int[] anIntArray4897 = new int[16];
    public static int anInt4898;
    public static int anInt4899;
    public static int anInt4900;
    public Class42 aClass42_4901;
    public static int anInt4902;
    public int[] anIntArray4903;
    public static int anInt4904;
    public static int anInt4905;
    public static int anInt4906;
    public static int anInt4907;
    public static int anInt4908;
    public static int anInt4909;
    public int[] anIntArray4910;
    public int[] anIntArray4911 = new int[16];
    public static int anInt4912;
    public static int anInt4913;
    public int[] anIntArray4914;
    public Class67_Sub26[][] aClass67_Sub26ArrayArray4915;
    public static int anInt4916;
    public static int anInt4917;
    public static int anInt4918;
    public static int anInt4919;
    public static int anInt4920;
    public static int anInt4921;
    public static int anInt4922;
    public static int anInt4923;
    public static int anInt4924;
    public int anInt4925;
    public static int anInt4926;
    public int[] anIntArray4927;
    public static int anInt4928;
    public static int anInt4929;
    public int[] anIntArray4930;
    public static int anInt4931;
    public int anInt4932;
    public static int anInt4933;
    public static int anInt4934;
    public static int anInt4935;
    public int[] anIntArray4936;
    public int[] anIntArray4937;
    public static int anInt4938;
    public Class67_Sub26[][] aClass67_Sub26ArrayArray4939;
    public static int anInt4940;
    public int[] anIntArray4941;
    public static int anInt4942;
    public int[] anIntArray4943;
    public static int anInt4944;
    public int[] anIntArray4945;
    public Class92 aClass92_4946;
    public boolean aBoolean4947;
    public Class67_Sub11_Sub2 aClass67_Sub11_Sub2_4948;
    public int anInt4949;
    public int anInt4950;
    public long aLong4951;
    public long aLong4952;
    public int anInt4953;
    public boolean aBoolean4954;
    public Class67_Sub4 aClass67_Sub4_4955;
    
    public synchronized void method1182(boolean arg0, boolean arg1) {
	aClass42_4901.method365();
	if (arg1 != false)
	    method1197(false, null, -74);
	anInt4894++;
	aClass67_Sub4_4955 = null;
	method1189(1639396615, arg0);
    }
    
    public static void method1183(byte arg0) {
	if (arg0 >= -62)
	    method1191(72, 116, 30);
	anInt4906++;
	Class67_Sub1_Sub5.anInt3876++;
    }
    
    public synchronized void method1184(byte arg0) {
	for (Class67_Sub27 class67_sub27
		 = (Class67_Sub27) aClass92_4946.method1483((byte) 36);
	     class67_sub27 != null;
	     class67_sub27
		 = (Class67_Sub27) aClass92_4946.method1480(arg0 ^ ~0x67))
	    class67_sub27.method1302(-1);
	anInt4913++;
	if (arg0 != -109)
	    method1194(-77, -58, 60);
    }
    
    public static void method1185(boolean arg0) {
	synchronized (Class81.aClass134_1648) {
	    if (arg0 != true)
		return;
	    RuntimeException_Sub1.anInt2626 = Class131_Sub7.anInt3710;
	    Class67_Sub17.anInt3104++;
	    if ((Class47.anInt962 ^ 0xffffffff) > -1) {
		for (int i = 0; (i ^ 0xffffffff) > -113; i++)
		    Class131_Sub7.aBooleanArray3698[i] = false;
		Class47.anInt962 = Class67_Sub27.anInt3299;
	    } else {
		while ((Class67_Sub27.anInt3299 ^ 0xffffffff)
		       != (Class47.anInt962 ^ 0xffffffff)) {
		    int i = RSString.anIntArray2649[Class67_Sub27.anInt3299];
		    Class67_Sub27.anInt3299
			= 1 + Class67_Sub27.anInt3299 & 0x7f;
		    if (i < 0)
			Class131_Sub7.aBooleanArray3698[i ^ 0xffffffff]
			    = false;
		    else
			Class131_Sub7.aBooleanArray3698[i] = true;
		}
	    }
	    Class131_Sub7.anInt3710 = Class70.anInt1404;
	}
	anInt4893++;
    }
    
    public void method1186(int arg0, int arg1, int arg2, int arg3) {
	method1196(64, (byte) 79, arg2, arg1);
	anInt4895++;
	if ((anIntArray4927[arg2] & 0x2) != 0) {
	    for (Class67_Sub26 class67_sub26
		     = (Class67_Sub26) aClass67_Sub11_Sub2_4948
					   .aClass50_4850.method433((byte) 65);
		 class67_sub26 != null;
		 class67_sub26
		     = (Class67_Sub26) aClass67_Sub11_Sub2_4948
					   .aClass50_4850.method443(50)) {
		if (arg2 == class67_sub26.anInt3282
		    && class67_sub26.anInt3276 < 0) {
		    aClass67_Sub26ArrayArray4915[arg2][class67_sub26.anInt3286]
			= null;
		    aClass67_Sub26ArrayArray4915[arg2][arg1] = class67_sub26;
		    int i
			= (class67_sub26.anInt3264
			   + (class67_sub26.anInt3257 * class67_sub26.anInt3271
			      >> -297601716));
		    class67_sub26.anInt3257 = 4096;
		    class67_sub26.anInt3264
			+= arg1 + -class67_sub26.anInt3286 << 2080603912;
		    class67_sub26.anInt3271 = -class67_sub26.anInt3264 + i;
		    class67_sub26.anInt3286 = arg1;
		    return;
		}
	    }
	}
	Class67_Sub27 class67_sub27
	    = ((Class67_Sub27)
	       aClass92_4946.method1489((byte) -85,
					(long) anIntArray4882[arg2]));
	if (class67_sub27 != null) {
	    Class67_Sub13_Sub1 class67_sub13_sub1
		= class67_sub27.aClass67_Sub13_Sub1Array3307[arg1];
	    if (class67_sub13_sub1 != null) {
		Class67_Sub26 class67_sub26 = new Class67_Sub26();
		class67_sub26.anInt3282 = arg2;
		class67_sub26.aClass67_Sub27_3279 = class67_sub27;
		class67_sub26.aClass67_Sub13_Sub1_3289 = class67_sub13_sub1;
		class67_sub26.aClass130_3287
		    = class67_sub27.aClass130Array3294[arg1];
		class67_sub26.anInt3270 = class67_sub27.aByteArray3304[arg1];
		class67_sub26.anInt3286 = arg1;
		class67_sub26.anInt3266
		    = ((class67_sub27.anInt3310 * arg3
			* (arg3 * class67_sub27.aByteArray3297[arg1])) - -1024
		       >> 2046576075);
		class67_sub26.anInt3285
		    = 0xff & class67_sub27.aByteArray3308[arg1];
		class67_sub26.anInt3264 = -(class67_sub27.aShortArray3312[arg1]
					    & 0x7fff) + (arg1 << 1522976168);
		class67_sub26.anInt3275 = 0;
		class67_sub26.anInt3263 = 0;
		class67_sub26.anInt3276 = -1;
		class67_sub26.anInt3258 = 0;
		class67_sub26.anInt3284 = 0;
		if (anIntArray4936[arg2] == 0)
		    class67_sub26.aClass67_Sub11_Sub3_3267
			= (Class67_Sub11_Sub3.method1172
			   (class67_sub13_sub1, method1204(0, class67_sub26),
			    method1219((byte) -124, class67_sub26),
			    method1216(108, class67_sub26)));
		else {
		    class67_sub26.aClass67_Sub11_Sub3_3267
			= (Class67_Sub11_Sub3.method1172
			   (class67_sub13_sub1, method1204(0, class67_sub26),
			    0, method1216(122, class67_sub26)));
		    method1197((class67_sub27.aShortArray3312[arg1]
				^ 0xffffffff) > -1,
			       class67_sub26, -1);
		}
		if (class67_sub27.aShortArray3312[arg1] < 0)
		    class67_sub26.aClass67_Sub11_Sub3_3267.method1142(-1);
		if (arg0 <= -103) {
		    if (class67_sub26.anInt3270 >= 0) {
			Class67_Sub26 class67_sub26_0_
			    = (aClass67_Sub26ArrayArray4939[arg2]
			       [class67_sub26.anInt3270]);
			if (class67_sub26_0_ != null
			    && class67_sub26_0_.anInt3276 < 0) {
			    aClass67_Sub26ArrayArray4915[arg2]
				[class67_sub26_0_.anInt3286]
				= null;
			    class67_sub26_0_.anInt3276 = 0;
			}
			aClass67_Sub26ArrayArray4939[arg2][(class67_sub26
							    .anInt3270)]
			    = class67_sub26;
		    }
		    aClass67_Sub11_Sub2_4948.aClass50_4850
			.method436(class67_sub26, false);
		    aClass67_Sub26ArrayArray4915[arg2][arg1] = class67_sub26;
		}
	    }
	}
    }
    
    public void method1187(int arg0, int arg1) {
	anInt4916++;
	if (arg1 == 0) {
	    for (Class67_Sub26 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method445(0));
		 class67_sub26 != null;
		 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method432(0))) {
		if ((arg0 < 0 || class67_sub26.anInt3282 == arg0)
		    && class67_sub26.anInt3276 < 0) {
		    aClass67_Sub26ArrayArray4915[class67_sub26.anInt3282]
			[class67_sub26.anInt3286]
			= null;
		    class67_sub26.anInt3276 = 0;
		}
	    }
	}
    }
    
    public synchronized void method1188(int arg0) {
	if (arg0 < -54) {
	    method1182(true, false);
	    anInt4918++;
	}
    }
    
    public void method1189(int arg0, boolean arg1) {
	anInt4908++;
	if (arg1)
	    method1193(-1, false);
	else
	    method1187(-1, 0);
	method1203(-1, arg0 + -1639369701);
	for (int i = 0; i < 16; i++)
	    anIntArray4882[i] = anIntArray4903[i];
	if (arg0 != 1639396615)
	    anIntArray4884 = null;
	for (int i = 0; (i ^ 0xffffffff) > -17; i++)
	    anIntArray4945[i] = Class75.method1379(anIntArray4903[i], -128);
    }
    
    public void method1190(int arg0, int arg1, int arg2) {
	anInt4934++;
	int i = 52 % ((arg1 - -29) / 35);
	anIntArray4911[arg0] = arg2;
	anIntArray4897[arg0]
	    = (int) (Math.pow(2.0, (double) arg2 * 5.4931640625E-4) * 2097152.0
		     + 0.5);
    }
    
    public synchronized Class67_Sub11 method1122() {
	anInt4887++;
	return aClass67_Sub11_Sub2_4948;
    }
    
    public static void method1191(int arg0, int arg1, int arg2) {
	anInt4929++;
	Class50 class50 = (Class67_Sub5_Sub2.aClass50ArrayArrayArray4471
			   [Canvas_Sub1.anInt59][arg2][arg1]);
	if (class50 == null)
	    Class131_Sub7_Sub1.method1888(Canvas_Sub1.anInt59, arg2, arg1);
	else {
	    int i = -99999999;
	    Class67_Sub5_Sub2 class67_sub5_sub2 = null;
	    for (Class67_Sub5_Sub2 class67_sub5_sub2_1_
		     = (Class67_Sub5_Sub2) class50.method445(0);
		 class67_sub5_sub2_1_ != null;
		 class67_sub5_sub2_1_
		     = (Class67_Sub5_Sub2) class50.method432(0)) {
		Class76 class76
		    = PacketParser.method1596((class67_sub5_sub2_1_
					   .aClass131_Sub4_4482.anInt3638),
					  -28322);
		int i_2_ = class76.anInt1507;
		if ((class76.anInt1559 ^ 0xffffffff) == -2)
		    i_2_ *= 1 + (class67_sub5_sub2_1_.aClass131_Sub4_4482
				 .anInt3641);
		if (i < i_2_) {
		    class67_sub5_sub2 = class67_sub5_sub2_1_;
		    i = i_2_;
		}
	    }
	    if (class67_sub5_sub2 == null)
		Class131_Sub7_Sub1.method1888(Canvas_Sub1.anInt59, arg2, arg1);
	    else {
		class50.method441(class67_sub5_sub2, (byte) -120);
		Class67_Sub5_Sub2 class67_sub5_sub2_3_
		    = (Class67_Sub5_Sub2) class50.method445(0);
		Class131_Sub4 class131_sub4 = null;
		Class131_Sub4 class131_sub4_4_ = null;
		for (/**/; class67_sub5_sub2_3_ != null;
		     class67_sub5_sub2_3_
			 = (Class67_Sub5_Sub2) class50.method432(0)) {
		    Class131_Sub4 class131_sub4_5_
			= class67_sub5_sub2_3_.aClass131_Sub4_4482;
		    if ((class131_sub4_5_.anInt3638 ^ 0xffffffff)
			!= (class67_sub5_sub2.aClass131_Sub4_4482.anInt3638
			    ^ 0xffffffff)) {
			if (class131_sub4_4_ == null)
			    class131_sub4_4_ = class131_sub4_5_;
			if ((class131_sub4_4_.anInt3638
			     != class131_sub4_5_.anInt3638)
			    && class131_sub4 == null)
			    class131_sub4 = class131_sub4_5_;
		    }
		}
		int i_6_ = 41 / ((arg0 - -39) / 60);
		long l = (long) (1610612736 + ((arg1 << 157600519) + arg2));
		Class23.method214(Canvas_Sub1.anInt59, arg2, arg1,
				  Class131_Sub5.method1826(Canvas_Sub1.anInt59,
							   arg2 * 128 - -64,
							   128 * arg1 + 64,
							   (byte) 94),
				  class67_sub5_sub2.aClass131_Sub4_4482, l,
				  class131_sub4_4_, class131_sub4);
	    }
	}
    }
    
    public int method1192(byte arg0) {
	if (arg0 <= 89)
	    return 20;
	anInt4885++;
	return anInt4925;
    }
    
    public void method1193(int arg0, boolean arg1) {
	anInt4928++;
	for (Class67_Sub26 class67_sub26
		 = ((Class67_Sub26)
		    aClass67_Sub11_Sub2_4948.aClass50_4850.method445(0));
	     class67_sub26 != null;
	     class67_sub26 = (Class67_Sub26) aClass67_Sub11_Sub2_4948
						 .aClass50_4850.method432(0)) {
	    if (arg0 < 0 || (arg0 ^ 0xffffffff) == (class67_sub26.anInt3282
						    ^ 0xffffffff)) {
		if (class67_sub26.aClass67_Sub11_Sub3_3267 != null) {
		    class67_sub26.aClass67_Sub11_Sub3_3267
			.method1148(Class89.anInt1833 / 100);
		    if (class67_sub26.aClass67_Sub11_Sub3_3267.method1169())
			aClass67_Sub11_Sub2_4948.aClass67_Sub11_Sub1_4864
			    .method1132
			    (class67_sub26.aClass67_Sub11_Sub3_3267);
		    class67_sub26.method1299((byte) 117);
		}
		if ((class67_sub26.anInt3276 ^ 0xffffffff) > -1)
		    aClass67_Sub26ArrayArray4915[class67_sub26.anInt3282]
			[class67_sub26.anInt3286]
			= null;
		class67_sub26.method606((byte) -118);
	    }
	}
	if (arg1 != false)
	    method1208(null, null, -119, (byte) -69, -41);
    }
    
    public synchronized void method1194(int arg0, int arg1, int arg2) {
	int i = 72 / ((arg1 - -61) / 55);
	if ((arg2 ^ 0xffffffff) > -1) {
	    for (int i_7_ = 0; i_7_ < 16; i_7_++)
		anIntArray4941[i_7_] = arg0;
	} else
	    anIntArray4941[arg2] = arg0;
	anInt4883++;
    }
    
    public synchronized void method1123(int arg0) {
	anInt4900++;
	if (aClass42_4901.method371()) {
	    int i = anInt4932 * aClass42_4901.anInt894 / Class89.anInt1833;
	    do {
		long l = aLong4952 - -((long) i * (long) arg0);
		if (aLong4951 + -l >= 0L) {
		    aLong4952 = l;
		    break;
		}
		int i_8_ = (int) ((-1L + (long) i + (aLong4951 + -aLong4952))
				  / (long) i);
		arg0 -= i_8_;
		aLong4952 += (long) i_8_ * (long) i;
		aClass67_Sub11_Sub2_4948.method1123(i_8_);
		method1195((byte) 68);
	    } while (aClass42_4901.method371());
	}
	aClass67_Sub11_Sub2_4948.method1123(arg0);
    }
    
    public void method1195(byte arg0) {
	anInt4909++;
	long l = aLong4951;
	int i = anInt4949;
	int i_9_ = anInt4950;
	if (aClass67_Sub4_4955 != null && anInt4953 == i_9_) {
	    method1218(aBoolean4947, aBoolean4954, (byte) -21,
		       aClass67_Sub4_4955);
	    method1195((byte) 90);
	} else {
	    while (i_9_ == anInt4950) {
		while (aClass42_4901.anIntArray893[i] == i_9_) {
		    aClass42_4901.method378(i);
		    int i_10_ = aClass42_4901.method375(i);
		    if ((i_10_ ^ 0xffffffff) == -2) {
			aClass42_4901.method364();
			aClass42_4901.method372(i);
			if (aClass42_4901.method370()) {
			    if (aClass67_Sub4_4955 != null) {
				method1201(123, aClass67_Sub4_4955,
					   aBoolean4947);
				method1195((byte) 68);
				return;
			    }
			    if (aBoolean4947 && i_9_ != 0)
				aClass42_4901.method377(l);
			    else {
				method1189(1639396615, true);
				aClass42_4901.method365();
				return;
			    }
			}
			break;
		    }
		    if ((0x80 & i_10_ ^ 0xffffffff) != -1)
			method1207(i_10_, -106);
		    aClass42_4901.method368(i);
		    aClass42_4901.method372(i);
		}
		i = aClass42_4901.method376();
		i_9_ = aClass42_4901.anIntArray893[i];
		l = aClass42_4901.method363(i_9_);
	    }
	    anInt4949 = i;
	    anInt4950 = i_9_;
	    if (arg0 < 56)
		anIntArray4936 = null;
	    aLong4951 = l;
	    if (aClass67_Sub4_4955 != null && i_9_ > anInt4953) {
		anInt4949 = -1;
		anInt4950 = anInt4953;
		aLong4951 = aClass42_4901.method363(anInt4950);
	    }
	}
    }
    
    public void method1196(int arg0, byte arg1, int arg2, int arg3) {
	anInt4926++;
	Class67_Sub26 class67_sub26 = aClass67_Sub26ArrayArray4915[arg2][arg3];
	if (class67_sub26 != null) {
	    aClass67_Sub26ArrayArray4915[arg2][arg3] = null;
	    int i = -54 / ((-16 - arg1) / 55);
	    if ((anIntArray4927[arg2] & 0x2) != 0) {
		for (Class67_Sub26 class67_sub26_11_
			 = (Class67_Sub26) aClass67_Sub11_Sub2_4948
					       .aClass50_4850.method445(0);
		     class67_sub26_11_ != null;
		     class67_sub26_11_
			 = (Class67_Sub26) aClass67_Sub11_Sub2_4948
					       .aClass50_4850.method432(0)) {
		    if (((class67_sub26_11_.anInt3282 ^ 0xffffffff)
			 == (class67_sub26.anInt3282 ^ 0xffffffff))
			&& (class67_sub26_11_.anInt3276 ^ 0xffffffff) > -1
			&& class67_sub26_11_ != class67_sub26) {
			class67_sub26.anInt3276 = 0;
			break;
		    }
		}
	    } else
		class67_sub26.anInt3276 = 0;
	}
    }
    
    public void method1197(boolean arg0, Class67_Sub26 arg1, int arg2) {
	anInt4881++;
	int i = arg1.aClass67_Sub13_Sub1_3289.aByteArray4956.length;
	if (arg2 != -1)
	    method1194(-60, -105, 26);
	int i_12_;
	if (arg0 && arg1.aClass67_Sub13_Sub1_3289.aBoolean4959) {
	    int i_13_ = i + (i + -arg1.aClass67_Sub13_Sub1_3289.anInt4957);
	    i <<= 8;
	    i_12_ = (int) ((long) anIntArray4936[arg1.anInt3282] * (long) i_13_
			   >> 1349329734);
	    if ((i_12_ ^ 0xffffffff) <= (i ^ 0xffffffff)) {
		arg1.aClass67_Sub11_Sub3_3267.method1177(true);
		i_12_ = -1 + (i + i) - i_12_;
	    }
	} else
	    i_12_ = (int) ((long) anIntArray4936[arg1.anInt3282] * (long) i
			   >> 1866182918);
	arg1.aClass67_Sub11_Sub3_3267.method1143(i_12_);
    }
    
    public synchronized int method1128() {
	anInt4923++;
	return 0;
    }
    
    public synchronized void method1198(boolean arg0) {
	if (arg0 != false)
	    method1207(21, 21);
	for (Class67_Sub27 class67_sub27
		 = (Class67_Sub27) aClass92_4946.method1483((byte) 64);
	     class67_sub27 != null;
	     class67_sub27 = (Class67_Sub27) aClass92_4946.method1480(11))
	    class67_sub27.method606((byte) -118);
	anInt4902++;
    }
    
    public synchronized void method1199(int arg0, int arg1) {
	if (arg1 < 27)
	    anInt4925 = 94;
	anInt4925 = arg0;
	anInt4919++;
    }
    
    public boolean method1200(int arg0, Class67_Sub26 arg1) {
	anInt4935++;
	if (arg1.aClass67_Sub11_Sub3_3267 == null) {
	    if (arg1.anInt3276 >= 0) {
		arg1.method606((byte) -118);
		if (arg1.anInt3270 > 0
		    && arg1 == (aClass67_Sub26ArrayArray4939[arg1.anInt3282]
				[arg1.anInt3270]))
		    aClass67_Sub26ArrayArray4939[arg1.anInt3282][(arg1
								  .anInt3270)]
			= null;
	    }
	    return true;
	}
	if (arg0 > -3)
	    return true;
	return false;
    }
    
    public synchronized void method1127(int[] arg0, int arg1, int arg2) {
	anInt4896++;
	if (aClass42_4901.method371()) {
	    int i = aClass42_4901.anInt894 * anInt4932 / Class89.anInt1833;
	    do {
		long l = aLong4952 - -((long) i * (long) arg2);
		if ((-l + aLong4951 ^ 0xffffffffffffffffL) <= -1L) {
		    aLong4952 = l;
		    break;
		}
		int i_14_
		    = (int) (((long) i + (-aLong4952 + (aLong4951 + -1L)))
			     / (long) i);
		aLong4952 += (long) i_14_ * (long) i;
		arg2 -= i_14_;
		aClass67_Sub11_Sub2_4948.method1127(arg0, arg1, i_14_);
		arg1 += i_14_;
		method1195((byte) 74);
	    } while (aClass42_4901.method371());
	}
	aClass67_Sub11_Sub2_4948.method1127(arg0, arg1, arg2);
    }
    
    public synchronized void method1201(int arg0, Class67_Sub4 arg1,
					boolean arg2) {
	method1218(arg2, true, (byte) -21, arg1);
	anInt4904++;
	if (arg0 <= 122)
	    aLong4951 = -108L;
    }
    
    public static void method1202() {
	if (Class126_Sub3.aClass67_Sub24ArrayArrayArray3453 != null) {
	    for (int i = 0;
		 i < Class126_Sub3.aClass67_Sub24ArrayArrayArray3453.length;
		 i++) {
		for (int i_15_ = 0; i_15_ < Class67_Sub27.anInt3301; i_15_++) {
		    for (int i_16_ = 0; i_16_ < Class67_Sub5_Sub16.anInt4782;
			 i_16_++)
			Class126_Sub3.aClass67_Sub24ArrayArrayArray3453[i]
			    [i_15_][i_16_]
			    = null;
		}
	    }
	}
	if (Class67_Sub1_Sub34.aClass67_Sub24ArrayArrayArray4334 != null) {
	    for (int i = 0;
		 i < (Class67_Sub1_Sub34
		      .aClass67_Sub24ArrayArrayArray4334).length;
		 i++) {
		for (int i_17_ = 0; i_17_ < Class67_Sub27.anInt3301; i_17_++) {
		    for (int i_18_ = 0; i_18_ < Class67_Sub5_Sub16.anInt4782;
			 i_18_++)
			Class67_Sub1_Sub34
			    .aClass67_Sub24ArrayArrayArray4334[i][i_17_][i_18_]
			    = null;
		}
	    }
	}
	Class129_Sub1.anInt3501 = 0;
	if (Class83.aClass68Array1672 != null) {
	    for (int i = 0; i < Class129_Sub1.anInt3501; i++)
		Class83.aClass68Array1672[i] = null;
	}
	if (Class67_Sub1_Sub16_Sub1.aClass36Array5099 != null) {
	    for (int i = 0; i < Canvas_Sub1.anInt62; i++)
		Class67_Sub1_Sub16_Sub1.aClass36Array5099[i] = null;
	    Canvas_Sub1.anInt62 = 0;
	}
	if (Class28.aClass36Array666 != null) {
	    for (int i = 0; i < Class28.aClass36Array666.length; i++)
		Class28.aClass36Array666[i] = null;
	}
    }
    
    public void method1203(int arg0, int arg1) {
	anInt4892++;
	if (arg0 < 0) {
	    for (arg0 = 0; (arg0 ^ 0xffffffff) > -17; arg0++)
		method1203(arg0, 26914);
	} else {
	    anIntArray4884[arg0] = 12800;
	    anIntArray4930[arg0] = 8192;
	    anIntArray4943[arg0] = 16383;
	    anIntArray4890[arg0] = 8192;
	    anIntArray4937[arg0] = 0;
	    if (arg1 == 26914) {
		anIntArray4910[arg0] = 8192;
		method1206(arg0, false);
		method1213(arg0, 0);
		anIntArray4927[arg0] = 0;
		anIntArray4886[arg0] = 32767;
		anIntArray4914[arg0] = 256;
		anIntArray4936[arg0] = 0;
		method1190(arg0, 107, 8192);
	    }
	}
    }
    
    public synchronized Class67_Sub11 method1124() {
	anInt4920++;
	return null;
    }
    
    public int method1204(int arg0, Class67_Sub26 arg1) {
	anInt4942++;
	int i
	    = (arg1.anInt3257 * arg1.anInt3271 >> 1980676332) + arg1.anInt3264;
	i += (anIntArray4914[arg1.anInt3282]
	      * (-8192 + anIntArray4890[arg1.anInt3282])) >> -1789281844;
	Class130 class130 = arg1.aClass130_3287;
	if ((class130.anInt2405 ^ 0xffffffff) < -1
	    && ((class130.anInt2406 ^ 0xffffffff) < -1
		|| anIntArray4937[arg1.anInt3282] > 0)) {
	    int i_19_ = class130.anInt2411 << -74759551;
	    int i_20_ = class130.anInt2406 << -1218005182;
	    if ((arg1.anInt3283 ^ 0xffffffff) > (i_19_ ^ 0xffffffff))
		i_20_ = arg1.anInt3283 * i_20_ / i_19_;
	    i_20_ += anIntArray4937[arg1.anInt3282] >> 1096399911;
	    double d
		= Math.sin(0.01227184630308513 * (double) (0x1ff
							   & arg1.anInt3260));
	    i += (int) ((double) i_20_ * d);
	}
	if (arg0 != 0)
	    return 114;
	int i_21_
	    = (int) (0.5 + ((double) (arg1.aClass67_Sub13_Sub1_3289.anInt4958
				      * 256)
			    * Math.pow(2.0, 3.255208333333333E-4 * (double) i)
			    / (double) Class89.anInt1833));
	if (i_21_ >= 1)
	    return i_21_;
	return 1;
    }
    
    public synchronized boolean method1205(byte arg0) {
	anInt4889++;
	int i = -51 / ((-19 - arg0) / 62);
	return aClass42_4901.method371();
    }
    
    public void method1206(int arg0, boolean arg1) {
	anInt4938++;
	if ((anIntArray4927[arg0] & 0x2) != 0) {
	    for (Class67_Sub26 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method445(0));
		 class67_sub26 != null;
		 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method432(0))) {
		if (class67_sub26.anInt3282 == arg0
		    && (aClass67_Sub26ArrayArray4915[arg0]
			[class67_sub26.anInt3286]) == null
		    && class67_sub26.anInt3276 < 0)
		    class67_sub26.anInt3276 = 0;
	    }
	}
	if (arg1 != false)
	    anIntArray4911 = null;
    }
    
    public void method1207(int arg0, int arg1) {
	if (arg1 >= -67)
	    method1204(-53, null);
	anInt4917++;
	int i = arg0 & 0xf0;
	if ((i ^ 0xffffffff) == -129) {
	    int i_22_ = arg0 & 0xf;
	    int i_23_ = (0x7f07 & arg0) >> -685235864;
	    int i_24_ = 0x7f & arg0 >> 295220688;
	    method1196(i_24_, (byte) 61, i_22_, i_23_);
	} else if ((i ^ 0xffffffff) == -145) {
	    int i_25_ = (0x7f55 & arg0) >> 1007670440;
	    int i_26_ = (arg0 & 0x7fb753) >> -2008524464;
	    int i_27_ = arg0 & 0xf;
	    if ((i_26_ ^ 0xffffffff) < -1)
		method1186(-111, i_25_, i_27_, i_26_);
	    else
		method1196(64, (byte) -114, i_27_, i_25_);
	} else if (i == 160) {
	    int i_28_ = arg0 & 0xf;
	    int i_29_ = (arg0 & 0x7f00fa) >> 1024984240;
	    int i_30_ = arg0 >> -1053345752 & 0x7f;
	    method1210(i_28_, i_30_, i_29_, 0);
	} else if (i == 176) {
	    int i_31_ = (0x7f13 & arg0) >> -2118363608;
	    int i_32_ = arg0 & 0xf;
	    int i_33_ = 0x7f & arg0 >> -277753328;
	    if ((i_31_ ^ 0xffffffff) == -1)
		anIntArray4945[i_32_]
		    = (Class75.method1379(-2080769, anIntArray4945[i_32_])
		       - -(i_33_ << 709533102));
	    if (i_31_ == 32)
		anIntArray4945[i_32_]
		    = ((i_33_ << 1716908487)
		       + Class75.method1379(-16257, anIntArray4945[i_32_]));
	    if ((i_31_ ^ 0xffffffff) == -2)
		anIntArray4937[i_32_]
		    = (Class75.method1379(-16257, anIntArray4937[i_32_])
		       + (i_33_ << -1091115257));
	    if (i_31_ == 33)
		anIntArray4937[i_32_]
		    = i_33_ + Class75.method1379(anIntArray4937[i_32_], -128);
	    if ((i_31_ ^ 0xffffffff) == -6)
		anIntArray4910[i_32_]
		    = ((i_33_ << 654274695)
		       + Class75.method1379(-16257, anIntArray4910[i_32_]));
	    if (i_31_ == 37)
		anIntArray4910[i_32_]
		    = Class75.method1379(anIntArray4910[i_32_], -128) + i_33_;
	    if (i_31_ == 7)
		anIntArray4884[i_32_]
		    = ((i_33_ << 1639396615)
		       + Class75.method1379(-16257, anIntArray4884[i_32_]));
	    if ((i_31_ ^ 0xffffffff) == -40)
		anIntArray4884[i_32_]
		    = i_33_ + Class75.method1379(-128, anIntArray4884[i_32_]);
	    if ((i_31_ ^ 0xffffffff) == -11)
		anIntArray4930[i_32_]
		    = (Class75.method1379(anIntArray4930[i_32_], -16257)
		       - -(i_33_ << -1841307385));
	    if (i_31_ == 42)
		anIntArray4930[i_32_]
		    = i_33_ + Class75.method1379(-128, anIntArray4930[i_32_]);
	    if (i_31_ == 11)
		anIntArray4943[i_32_]
		    = ((i_33_ << -1498206201)
		       + Class75.method1379(-16257, anIntArray4943[i_32_]));
	    if (i_31_ == 43)
		anIntArray4943[i_32_]
		    = i_33_ + Class75.method1379(anIntArray4943[i_32_], -128);
	    if ((i_31_ ^ 0xffffffff) == -65) {
		if (i_33_ < 64)
		    anIntArray4927[i_32_]
			= Class75.method1379(anIntArray4927[i_32_], -2);
		else
		    anIntArray4927[i_32_]
			= Class67_Sub20.method1273(anIntArray4927[i_32_], 1);
	    }
	    if (i_31_ == 65) {
		if ((i_33_ ^ 0xffffffff) <= -65)
		    anIntArray4927[i_32_]
			= Class67_Sub20.method1273(anIntArray4927[i_32_], 2);
		else {
		    method1206(i_32_, false);
		    anIntArray4927[i_32_]
			= Class75.method1379(anIntArray4927[i_32_], -3);
		}
	    }
	    if ((i_31_ ^ 0xffffffff) == -100)
		anIntArray4886[i_32_]
		    = (Class75.method1379(anIntArray4886[i_32_], 127)
		       - -(i_33_ << 489578727));
	    if (i_31_ == 98)
		anIntArray4886[i_32_]
		    = i_33_ + Class75.method1379(16256, anIntArray4886[i_32_]);
	    if ((i_31_ ^ 0xffffffff) == -102)
		anIntArray4886[i_32_]
		    = 16384 - (-Class75.method1379(anIntArray4886[i_32_], 127)
			       - (i_33_ << 435376423));
	    if (i_31_ == 100)
		anIntArray4886[i_32_]
		    = 16384 - -Class75.method1379(anIntArray4886[i_32_],
						  16256) - -i_33_;
	    if ((i_31_ ^ 0xffffffff) == -121)
		method1193(i_32_, false);
	    if ((i_31_ ^ 0xffffffff) == -122)
		method1203(i_32_, 26914);
	    if (i_31_ == 123)
		method1187(i_32_, 0);
	    if ((i_31_ ^ 0xffffffff) == -7) {
		int i_34_ = anIntArray4886[i_32_];
		if (i_34_ == 16384)
		    anIntArray4914[i_32_]
			= (Class75.method1379(-16257, anIntArray4914[i_32_])
			   + (i_33_ << -2021009433));
	    }
	    if ((i_31_ ^ 0xffffffff) == -39) {
		int i_35_ = anIntArray4886[i_32_];
		if ((i_35_ ^ 0xffffffff) == -16385)
		    anIntArray4914[i_32_]
			= (Class75.method1379(-128, anIntArray4914[i_32_])
			   + i_33_);
	    }
	    if ((i_31_ ^ 0xffffffff) == -17)
		anIntArray4936[i_32_]
		    = (Class75.method1379(anIntArray4936[i_32_], -16257)
		       - -(i_33_ << 1377644679));
	    if (i_31_ == 48)
		anIntArray4936[i_32_]
		    = Class75.method1379(anIntArray4936[i_32_], -128) - -i_33_;
	    if (i_31_ == 81) {
		if (i_33_ >= 64)
		    anIntArray4927[i_32_]
			= Class67_Sub20.method1273(anIntArray4927[i_32_], 4);
		else {
		    method1213(i_32_, 0);
		    anIntArray4927[i_32_]
			= Class75.method1379(anIntArray4927[i_32_], -5);
		}
	    }
	    if (i_31_ == 17)
		method1190(i_32_, 44,
			   (i_33_ << -289432537) + (anIntArray4911[i_32_]
						    & ~0x3f80));
	    if (i_31_ == 49)
		method1190(i_32_, -124,
			   i_33_ + (~0x7f & anIntArray4911[i_32_]));
	} else if ((i ^ 0xffffffff) == -193) {
	    int i_36_ = arg0 & 0xf;
	    int i_37_ = 0x7f & arg0 >> -1423486840;
	    method1214(i_36_, i_37_ + anIntArray4945[i_36_], 256);
	} else if ((i ^ 0xffffffff) == -209) {
	    int i_38_ = 0xf & arg0;
	    int i_39_ = (0x7fdb & arg0) >> -2108245784;
	    method1215(-28972, i_39_, i_38_);
	} else if ((i ^ 0xffffffff) == -225) {
	    int i_40_
		= (0x3f80 & arg0 >> -286515063) - -(0x7f & arg0 >> -418997016);
	    int i_41_ = arg0 & 0xf;
	    method1212(true, i_41_, i_40_);
	} else {
	    i = arg0 & 0xff;
	    if ((i ^ 0xffffffff) == -256)
		method1189(1639396615, true);
	}
    }
    
    public boolean method1208(int[] arg0, Class67_Sub26 arg1, int arg2,
			      byte arg3, int arg4) {
	try {
	    arg1.anInt3281 = Class89.anInt1833 / 100;
	    anInt4944++;
	    if ((arg1.anInt3276 ^ 0xffffffff) <= -1
		&& (arg1.aClass67_Sub11_Sub3_3267 == null
		    || arg1.aClass67_Sub11_Sub3_3267.method1145())) {
		arg1.method1299((byte) 123);
		arg1.method606((byte) -118);
		if ((arg1.anInt3270 ^ 0xffffffff) < -1
		    && (aClass67_Sub26ArrayArray4939[arg1.anInt3282]
			[arg1.anInt3270]) == arg1)
		    aClass67_Sub26ArrayArray4939[arg1.anInt3282][(arg1
								  .anInt3270)]
			= null;
		return true;
	    }
	    int i = arg1.anInt3257;
	    if (i > 0) {
		i -= (int) (16.0 * Math.pow(2.0, ((double) (anIntArray4910
							    [arg1.anInt3282])
						  * 4.921259842519685E-4))
			    + 0.5);
		if ((i ^ 0xffffffff) > -1)
		    i = 0;
		arg1.anInt3257 = i;
	    }
	    arg1.aClass67_Sub11_Sub3_3267.method1163(method1204(0, arg1));
	    double d = (5.086263020833333E-6
			* (double) ((arg1.anInt3286 + -60 << -261425336)
				    + (arg1.anInt3257 * arg1.anInt3271
				       >> -2023677908)));
	    boolean bool = false;
	    arg1.anInt3283++;
	    Class130 class130 = arg1.aClass130_3287;
	    int i_42_ = -115 / ((arg3 - 62) / 53);
	    arg1.anInt3260 += class130.anInt2405;
	    if ((class130.anInt2407 ^ 0xffffffff) < -1) {
		if ((class130.anInt2413 ^ 0xffffffff) >= -1)
		    arg1.anInt3263 += 128;
		else
		    arg1.anInt3263
			+= (int) ((128.0
				   * Math.pow(2.0,
					      d * (double) class130.anInt2413))
				  + 0.5);
		if ((arg1.anInt3263 * class130.anInt2407 ^ 0xffffffff)
		    <= -819201)
		    bool = true;
	    }
	    if (class130.aByteArray2410 != null) {
		if (class130.anInt2403 > 0)
		    arg1.anInt3275
			+= (int) (0.5 + 128.0 * Math.pow(2.0,
							 ((double) (class130
								    .anInt2403)
							  * d)));
		else
		    arg1.anInt3275 += 128;
		for (/**/;
		     (((arg1.anInt3258 ^ 0xffffffff)
		       > (class130.aByteArray2410.length - 2 ^ 0xffffffff))
		      && arg1.anInt3275 > (0xff00 & ((class130.aByteArray2410
						      [2 + arg1.anInt3258])
						     << 1095364264)));
		     arg1.anInt3258 += 2) {
		    /* empty */
		}
		if (-2 + class130.aByteArray2410.length == arg1.anInt3258
		    && class130.aByteArray2410[arg1.anInt3258 + 1] == 0)
		    bool = true;
	    }
	    if ((arg1.anInt3276 ^ 0xffffffff) <= -1
		&& class130.aByteArray2423 != null
		&& (anIntArray4927[arg1.anInt3282] & 0x1 ^ 0xffffffff) == -1
		&& ((arg1.anInt3270 ^ 0xffffffff) > -1
		    || arg1 != (aClass67_Sub26ArrayArray4939[arg1.anInt3282]
				[arg1.anInt3270]))) {
		if ((class130.anInt2417 ^ 0xffffffff) >= -1)
		    arg1.anInt3276 += 128;
		else
		    arg1.anInt3276
			+= (int) (0.5
				  + (Math.pow(2.0,
					      (double) class130.anInt2417 * d)
				     * 128.0));
		for (/**/;
		     (((-2 + class130.aByteArray2423.length ^ 0xffffffff)
		       < (arg1.anInt3284 ^ 0xffffffff))
		      && ((arg1.anInt3276 ^ 0xffffffff)
			  < (0xff00 & (class130.aByteArray2423
				       [2 + arg1.anInt3284]) << 2057745608
			     ^ 0xffffffff)));
		     arg1.anInt3284 += 2) {
		    /* empty */
		}
		if ((class130.aByteArray2423.length - 2 ^ 0xffffffff)
		    == (arg1.anInt3284 ^ 0xffffffff))
		    bool = true;
	    }
	    if (bool) {
		arg1.aClass67_Sub11_Sub3_3267.method1148(arg1.anInt3281);
		if (arg0 != null)
		    arg1.aClass67_Sub11_Sub3_3267.method1127(arg0, arg4, arg2);
		else
		    arg1.aClass67_Sub11_Sub3_3267.method1123(arg2);
		if (arg1.aClass67_Sub11_Sub3_3267.method1169())
		    aClass67_Sub11_Sub2_4948.aClass67_Sub11_Sub1_4864
			.method1132(arg1.aClass67_Sub11_Sub3_3267);
		arg1.method1299((byte) 117);
		if ((arg1.anInt3276 ^ 0xffffffff) <= -1) {
		    arg1.method606((byte) -118);
		    if (arg1.anInt3270 > 0
			&& (aClass67_Sub26ArrayArray4939[arg1.anInt3282]
			    [arg1.anInt3270]) == arg1)
			aClass67_Sub26ArrayArray4939[arg1.anInt3282]
			    [arg1.anInt3270]
			    = null;
		}
		return true;
	    }
	    arg1.aClass67_Sub11_Sub3_3267.method1157(arg1.anInt3281,
						     method1219((byte) -124,
								arg1),
						     method1216(71, arg1));
	    return false;
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       ("ng.T("
						+ (arg0 != null ? "{...}"
						   : "null")
						+ ','
						+ (arg1 != null ? "{...}"
						   : "null")
						+ ',' + arg2 + ',' + arg3 + ','
						+ arg4 + ')'));
	}
    }
    
    public synchronized boolean method1209(Class83 arg0, int arg1, int arg2,
					   Class9 arg3, Class67_Sub4 arg4) {
	try {
	    arg4.method818();
	    anInt4924++;
	    int[] is = null;
	    boolean bool = true;
	    if ((arg2 ^ 0xffffffff) < -1)
		is = new int[] { arg2 };
	    int i = -102 / ((arg1 - -66) / 53);
	    for (Class67_Sub16 class67_sub16
		     = ((Class67_Sub16)
			arg4.aClass92_2856.method1483((byte) 25));
		 class67_sub16 != null;
		 class67_sub16
		     = (Class67_Sub16) arg4.aClass92_2856.method1480(11)) {
		int i_43_ = (int) class67_sub16.aLong1344;
		Class67_Sub27 class67_sub27
		    = ((Class67_Sub27)
		       aClass92_4946.method1489((byte) -52, (long) i_43_));
		if (class67_sub27 == null) {
		    class67_sub27
			= Class67_Sub1_Sub37.method799(i_43_, arg3, -3);
		    if (class67_sub27 == null) {
			bool = false;
			continue;
		    }
		    aClass92_4946.method1488((byte) -89, class67_sub27,
					     (long) i_43_);
		}
		if (!class67_sub27.method1301(arg0, is, (byte) 25,
					      class67_sub16.aByteArray3086))
		    bool = false;
	    }
	    if (bool)
		arg4.method819();
	    return bool;
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718
		      (runtimeexception,
		       ("ng.L(" + (arg0 != null ? "{...}" : "null") + ','
			+ arg1 + ',' + arg2 + ','
			+ (arg3 != null ? "{...}" : "null") + ','
			+ (arg4 != null ? "{...}" : "null") + ')'));
	}
    }
    
    public void method1210(int arg0, int arg1, int arg2, int arg3) {
	anInt4907++;
	if (arg3 != 0)
	    method1185(true);
    }
    
    public void method1211(int arg0, byte arg1, int arg2) {
	anInt4933++;
	if (arg1 != 40)
	    aLong4951 = -8L;
	anIntArray4903[arg0] = arg2;
	anIntArray4945[arg0] = Class75.method1379(arg2, -128);
	method1214(arg0, arg2, arg1 ^ 0x128);
    }
    
    public void method1212(boolean arg0, int arg1, int arg2) {
	anInt4891++;
	if (arg0 != true)
	    anInt4950 = -124;
	anIntArray4890[arg1] = arg2;
    }
    
    public void method1213(int arg0, int arg1) {
	if ((0x4 & anIntArray4927[arg0] ^ 0xffffffff) != -1) {
	    for (Class67_Sub26 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method445(0));
		 class67_sub26 != null;
		 class67_sub26
		     = ((Class67_Sub26)
			aClass67_Sub11_Sub2_4948.aClass50_4850.method432(0))) {
		if (arg0 == class67_sub26.anInt3282)
		    class67_sub26.anInt3261 = 0;
	    }
	}
	anInt4922++;
	if (arg1 != 0)
	    method1192((byte) -14);
    }
    
    public void method1214(int arg0, int arg1, int arg2) {
	anInt4940++;
	if (anIntArray4882[arg0] != arg1) {
	    anIntArray4882[arg0] = arg1;
	    for (int i = 0; i < 128; i++)
		aClass67_Sub26ArrayArray4939[arg0][i] = null;
	}
	if (arg2 != 256)
	    anInt4949 = 50;
    }
    
    public void method1215(int arg0, int arg1, int arg2) {
	if (arg0 != -28972)
	    anIntArray4943 = null;
	anInt4899++;
    }
    
    public int method1216(int arg0, Class67_Sub26 arg1) {
	int i = 104 / ((arg0 - 24) / 45);
	anInt4912++;
	int i_44_ = anIntArray4930[arg1.anInt3282];
	if (i_44_ >= 8192)
	    return 16384 - ((-i_44_ + 16384) * (-arg1.anInt3285 + 128) - -32
			    >> 1570566534);
	return 32 + i_44_ * arg1.anInt3285 >> 710575270;
    }
    
    public synchronized void method1217(int arg0, int arg1, int arg2) {
	method1211(arg1, (byte) 40, arg0);
	if (arg2 < 81)
	    method1200(97, null);
	anInt4905++;
    }
    
    public synchronized void method1218(boolean arg0, boolean arg1, byte arg2,
					Class67_Sub4 arg3) {
	if (arg2 == -21) {
	    method1182(arg1, false);
	    aClass42_4901.method374(arg3.aByteArray2857);
	    aBoolean4947 = arg0;
	    anInt4921++;
	    aLong4952 = 0L;
	    int i = aClass42_4901.method369();
	    for (int i_45_ = 0; i > i_45_; i_45_++) {
		aClass42_4901.method378(i_45_);
		aClass42_4901.method368(i_45_);
		aClass42_4901.method372(i_45_);
	    }
	    anInt4949 = aClass42_4901.method376();
	    anInt4950 = aClass42_4901.anIntArray893[anInt4949];
	    aLong4951 = aClass42_4901.method363(anInt4950);
	}
    }
    
    public int method1219(byte arg0, Class67_Sub26 arg1) {
	anInt4931++;
	if (anIntArray4941[arg1.anInt3282] == 0)
	    return 0;
	Class130 class130 = arg1.aClass130_3287;
	int i = (4096 + (anIntArray4943[arg1.anInt3282]
			 * anIntArray4884[arg1.anInt3282])
		 >> -2110800819);
	i = 16384 + i * i >> 1552967375;
	i = arg1.anInt3266 * i - -16384 >> -659574865;
	if (arg0 != -124)
	    method1219((byte) -62, null);
	i = anInt4925 * i + 128 >> -1792678488;
	i = 128 + i * anIntArray4941[arg1.anInt3282] >> -669155096;
	if (class130.anInt2407 > 0)
	    i = (int) (Math.pow(0.5, ((double) class130.anInt2407
				      * ((double) arg1.anInt3263
					 * 1.953125E-5))) * (double) i
		       + 0.5);
	if (class130.aByteArray2410 != null) {
	    int i_46_ = arg1.anInt3275;
	    int i_47_ = class130.aByteArray2410[arg1.anInt3258 - -1];
	    if (arg1.anInt3258 < class130.aByteArray2410.length + -2) {
		int i_48_ = ((class130.aByteArray2410[arg1.anInt3258] & 0xff)
			     << -430668600);
		int i_49_
		    = ((0xff & class130.aByteArray2410[2 + arg1.anInt3258])
		       << -1231491192);
		i_47_ += (class130.aByteArray2410[3 + arg1.anInt3258]
			  + -i_47_) * (i_46_ + -i_48_) / (i_49_ - i_48_);
	    }
	    i = 32 + i * i_47_ >> 2130283974;
	}
	if ((arg1.anInt3276 ^ 0xffffffff) < -1
	    && class130.aByteArray2423 != null) {
	    int i_50_ = arg1.anInt3276;
	    int i_51_ = class130.aByteArray2423[1 + arg1.anInt3284];
	    if (class130.aByteArray2423.length + -2 > arg1.anInt3284) {
		int i_52_
		    = (0xff00
		       & class130.aByteArray2423[arg1.anInt3284] << 870356936);
		int i_53_
		    = 0xff00 & (class130.aByteArray2423[arg1.anInt3284 + 2]
				<< 1492769256);
		i_51_ += ((i_50_ + -i_52_)
			  * (-i_51_
			     + class130.aByteArray2423[arg1.anInt3284 + 3])
			  / (-i_52_ + i_53_));
	    }
	    i = i_51_ * i - -32 >> -1913524410;
	}
	return i;
    }
    
    public Class67_Sub11_Sub4() {
	anIntArray4882 = new int[16];
	anIntArray4914 = new int[16];
	anIntArray4903 = new int[16];
	anIntArray4890 = new int[16];
	anIntArray4930 = new int[16];
	anInt4925 = 256;
	anInt4932 = 1000000;
	anIntArray4936 = new int[16];
	anIntArray4927 = new int[16];
	aClass67_Sub26ArrayArray4939 = new Class67_Sub26[16][128];
	anIntArray4941 = new int[16];
	anIntArray4937 = new int[16];
	anIntArray4943 = new int[16];
	anIntArray4945 = new int[16];
	aClass67_Sub26ArrayArray4915 = new Class67_Sub26[16][128];
	anIntArray4910 = new int[16];
	aClass42_4901 = new Class42();
	aClass67_Sub11_Sub2_4948 = new Class67_Sub11_Sub2(this);
	aClass92_4946 = new Class92(128);
	method1194(256, 97, -1);
	method1189(1639396615, true);
    }
}
