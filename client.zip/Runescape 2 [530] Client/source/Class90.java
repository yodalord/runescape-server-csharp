/* Class90 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class90
{
    public static int anInt1840;
    public static RSString aRSString_1841
	= (Class134.method1914
	   ("; Expires=Thu)1 01)2Jan)21970 00:00:00 GMT; Max)2Age=0",
	    (byte) 119));
    public static int anInt1842;
    public static Class120 aClass120_1843;
    public static RSString aRSString_1844
	= Class134.method1914("null", (byte) 48);
    public static RSString aRSString_1845
	= Class134.method1914("Polices charg-Bes", (byte) 49);
    public static Class9 aClass9_1846;
    public static int anInt1847;
    public static boolean[] aBooleanArray1848;
    public static int[] anIntArray1849;
    public static RSString aRSString_1850;
    public static RSString aRSString_1851;
    public static RSString aRSString_1852;
    
    public static void method1472(int arg0) {
	int i = 56 % ((71 - arg0) / 39);
	aRSString_1845 = null;
	aClass9_1846 = null;
	aRSString_1844 = null;
	aRSString_1852 = null;
	anIntArray1849 = null;
	aRSString_1850 = null;
	aClass120_1843 = null;
	aRSString_1851 = null;
	aRSString_1841 = null;
	aBooleanArray1848 = null;
    }
    
    public static void method1473(int arg0, byte arg1) {
	anInt1840++;
	Class67_Sub5_Sub3 class67_sub5_sub3
	    = Class103.method1558(arg0, false, 5);
	if (arg1 <= 96)
	    method1472(123);
	class67_sub5_sub3.method844(0);
    }
    
    public Class90() {
	new Class61();
    }
    
    static {
	aClass120_1843 = new Class120();
	aBooleanArray1848 = new boolean[100];
	anInt1847 = 0;
	aRSString_1850 = Class134.method1914("<col=ffffff> )4 ", (byte) 68);
	aRSString_1851 = Class134.method1914("Lade)3)3)3", (byte) 37);
	anIntArray1849 = new int[4096];
	aRSString_1852
	    = (Class134.method1914
	       ("Chargement de RuneScape en cours )2 veuillez patienter)3)3)3",
		(byte) 81));
    }
}
