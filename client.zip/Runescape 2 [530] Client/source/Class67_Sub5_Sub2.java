/* Class67_Sub5_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub5_Sub2 extends Class67_Sub5
{
    public static int anInt4465;
    public static int anInt4466;
    public static RSString aRSString_4467
	= Class134.method1914("Connection lost)3", (byte) 114);
    public static boolean aBoolean4468;
    public static RSString aRSString_4469 = aRSString_4467;
    public static int anInt4470;
    public static Class50[][][] aClass50ArrayArrayArray4471;
    public static int anInt4472;
    public static int anInt4473;
    public static int anInt4474;
    public static Class31 aClass31_4475;
    public static RSString aRSString_4476;
    public static int anInt4477;
    public static int anInt4478;
    public static int anInt4479;
    public static int anInt4480;
    public static int anInt4481;
    public Class131_Sub4 aClass131_Sub4_4482;
    public static RSString aRSString_4483;
    
    public static void method832(int arg0, int arg1, int arg2, int arg3,
				 int arg4, int arg5, int arg6, boolean arg7) {
	anInt4465++;
	int i = arg5;
	int i_0_ = 0;
	int i_1_ = 0;
	int i_2_ = -arg2 + arg1;
	int i_3_ = i_2_ * i_2_;
	int i_4_ = arg5 * arg5;
	int i_5_ = arg5 - arg2;
	int i_6_ = arg1 * arg1;
	int i_7_ = i_6_ << 953952513;
	int i_8_ = i_3_ << -1541308735;
	int i_9_ = i_5_ * i_5_;
	int i_10_ = i_9_ << 871414977;
	int i_11_ = i_5_ << 1695344385;
	int i_12_ = i_4_ << -717247039;
	int i_13_ = arg5 << -1910262047;
	int i_14_ = (1 - i_13_) * i_6_ - -i_12_;
	int i_15_ = i_4_ - i_7_ * (-1 + i_13_);
	int i_16_ = i_3_ * (1 + -i_11_) - -i_10_;
	int i_17_ = i_9_ + -(i_8_ * (i_11_ - 1));
	int i_18_ = i_6_ << 2145133378;
	int i_19_ = i_4_ << 1435552546;
	int i_20_ = i_3_ << 164944162;
	int i_21_ = i_7_ * (-3 + i_13_);
	int i_22_ = 3 * i_10_;
	int i_23_ = i_12_ * 3;
	int i_24_ = i_19_;
	int i_25_ = (-3 + i_11_) * i_8_;
	int i_26_ = i_9_ << -160484638;
	int i_27_ = (-1 + arg5) * i_18_;
	int i_28_ = i_20_ * (i_5_ - 1);
	int[] is = Class67_Sub29.anIntArrayArray3338[arg6];
	if (arg7 == false) {
	    int i_29_ = i_26_;
	    Class67_Sub1_Sub11.method665(2, -arg1 + arg0, is, -i_2_ + arg0,
					 arg3);
	    Class67_Sub1_Sub11.method665(2, -i_2_ + arg0, is, arg0 - -i_2_,
					 arg4);
	    Class67_Sub1_Sub11.method665(2, arg0 - -i_2_, is, arg1 + arg0,
					 arg3);
	    while ((i ^ 0xffffffff) < -1) {
		if (i_14_ < 0) {
		    while (i_14_ < 0) {
			i_15_ += i_24_;
			i_24_ += i_19_;
			i_1_++;
			i_14_ += i_23_;
			i_23_ += i_19_;
		    }
		}
		boolean bool = (i ^ 0xffffffff) >= (i_5_ ^ 0xffffffff);
		i--;
		int i_30_ = arg6 - i;
		if (i_15_ < 0) {
		    i_15_ += i_24_;
		    i_1_++;
		    i_24_ += i_19_;
		    i_14_ += i_23_;
		    i_23_ += i_19_;
		}
		int i_31_ = -i_1_ + arg0;
		i_15_ += -i_21_;
		if (bool) {
		    if (i_16_ < 0) {
			while (i_16_ < 0) {
			    i_0_++;
			    i_16_ += i_22_;
			    i_22_ += i_26_;
			    i_17_ += i_29_;
			    i_29_ += i_26_;
			}
		    }
		    if ((i_17_ ^ 0xffffffff) > -1) {
			i_16_ += i_22_;
			i_0_++;
			i_17_ += i_29_;
			i_29_ += i_26_;
			i_22_ += i_26_;
		    }
		    i_16_ += -i_28_;
		    i_28_ -= i_20_;
		    i_17_ += -i_25_;
		    i_25_ -= i_20_;
		}
		i_14_ += -i_27_;
		int i_32_ = i + arg6;
		i_21_ -= i_18_;
		i_27_ -= i_18_;
		int i_33_ = i_1_ + arg0;
		if (!bool) {
		    Class67_Sub1_Sub11.method665(2, i_31_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_30_]),
						 i_33_, arg3);
		    Class67_Sub1_Sub11.method665(2, i_31_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_32_]),
						 i_33_, arg3);
		} else {
		    int i_34_ = arg0 + i_0_;
		    int i_35_ = -i_0_ + arg0;
		    Class67_Sub1_Sub11.method665(2, i_31_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_30_]),
						 i_35_, arg3);
		    Class67_Sub1_Sub11.method665(2, i_35_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_30_]),
						 i_34_, arg4);
		    Class67_Sub1_Sub11.method665(2, i_34_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_30_]),
						 i_33_, arg3);
		    Class67_Sub1_Sub11.method665(2, i_31_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_32_]),
						 i_35_, arg3);
		    Class67_Sub1_Sub11.method665(2, i_35_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_32_]),
						 i_34_, arg4);
		    Class67_Sub1_Sub11.method665(2, i_34_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_32_]),
						 i_33_, arg3);
		}
	    }
	}
    }
    
    public static void method833(int arg0, boolean arg1, int arg2, int arg3,
				 int arg4, int arg5, int arg6, int arg7,
				 int arg8, int arg9) {
	anInt4481++;
	Class67_Sub6 class67_sub6 = null;
	Class67_Sub6 class67_sub6_36_
	    = (Class67_Sub6) Class67_Sub1_Sub39.aClass50_4441.method445(0);
	if (arg1 != false)
	    method837(null, (byte) 125);
	for (/**/; class67_sub6_36_ != null;
	     class67_sub6_36_ = (Class67_Sub6) Class67_Sub1_Sub39
						   .aClass50_4441
						   .method432(0)) {
	    if ((class67_sub6_36_.anInt2871 ^ 0xffffffff) == (arg6
							      ^ 0xffffffff)
		&& (class67_sub6_36_.anInt2874 ^ 0xffffffff) == (arg3
								 ^ 0xffffffff)
		&& (class67_sub6_36_.anInt2891 ^ 0xffffffff) == (arg5
								 ^ 0xffffffff)
		&& arg7 == class67_sub6_36_.anInt2877) {
		class67_sub6 = class67_sub6_36_;
		break;
	    }
	}
	if (class67_sub6 == null) {
	    class67_sub6 = new Class67_Sub6();
	    class67_sub6.anInt2891 = arg5;
	    class67_sub6.anInt2874 = arg3;
	    class67_sub6.anInt2871 = arg6;
	    class67_sub6.anInt2877 = arg7;
	    Class55_Sub2_Sub1.method473(class67_sub6, 0);
	    Class67_Sub1_Sub39.aClass50_4441.method436(class67_sub6, arg1);
	}
	class67_sub6.anInt2883 = arg0;
	class67_sub6.anInt2892 = arg9;
	class67_sub6.anInt2869 = arg4;
	class67_sub6.anInt2880 = arg2;
	class67_sub6.anInt2889 = arg8;
    }
    
    public static void method834(byte arg0) {
	aClass31_4475 = null;
	aRSString_4467 = null;
	aRSString_4483 = null;
	if (arg0 != 75)
	    anInt4478 = -51;
	aRSString_4476 = null;
	aRSString_4469 = null;
	aClass50ArrayArrayArray4471 = null;
    }
    
    public static void method835(int arg0) {
	Class68.aClass7Array1366 = null;
	if (arg0 == 1) {
	    Class37.method319(Class49.anInt1010, 0, 0, Class56.anInt1097, 0,
			      -1, 0, Class54.anInt1080, arg0 ^ 0x5823);
	    anInt4470++;
	    if (Class68.aClass7Array1366 != null) {
		InputStream_Sub1.method51(Class84.anInt1704,
					  Class68.aClass7Array1366,
					  -1412584499, Class49.anInt1010, 0,
					  (Class67_Sub1_Sub34.aClass7_4337
					   .anInt234),
					  Class56.anInt1097,
					  Class67_Sub1_Sub7.anInt3912, true,
					  0);
		Class68.aClass7Array1366 = null;
	    }
	}
    }
    
    public static void method836(int arg0, int arg1, int arg2, int arg3,
				 int arg4, int arg5, int arg6, int arg7) {
	anInt4480++;
	int i = arg5;
	int i_37_ = 0;
	int i_38_ = 0;
	int i_39_ = arg7 + -arg1;
	int i_40_ = -arg1 + arg5;
	int i_41_ = arg5 * arg5;
	int i_42_ = i_39_ * i_39_;
	int i_43_ = i_40_ * i_40_;
	int i_44_ = arg7 * arg7;
	int i_45_ = i_41_ << 643724449;
	int i_46_ = i_42_ << -1238113791;
	int i_47_ = i_44_ << -1787398207;
	int i_48_ = i_43_ << 1731897921;
	int i_49_ = arg5 << -1643025311;
	if (arg4 != -23880)
	    aRSString_4469 = null;
	int i_50_ = i_40_ << -882599519;
	int i_51_ = (1 - i_49_) * i_44_ + i_45_;
	int i_52_ = -((-1 + i_49_) * i_47_) + i_41_;
	int i_53_ = (-i_50_ + 1) * i_42_ - -i_48_;
	int i_54_ = i_43_ - i_46_ * (i_50_ - 1);
	int i_55_ = i_44_ << 2080509154;
	int i_56_ = i_43_ << -1431994910;
	int i_57_ = i_45_ * 3;
	int i_58_ = i_41_ << 1545127906;
	int i_59_ = i_42_ << -1205598110;
	int i_60_ = (i_49_ + -3) * i_47_;
	int i_61_ = (-3 + i_50_) * i_46_;
	int i_62_ = 3 * i_48_;
	int i_63_ = i_55_ * (arg5 + -1);
	int i_64_ = i_58_;
	int i_65_ = i_56_;
	if ((Class55_Sub2.anInt2801 ^ 0xffffffff) >= (arg0 ^ 0xffffffff)
	    && arg0 <= OutputStream_Sub1.anInt87) {
	    int[] is = Class67_Sub29.anIntArrayArray3338[arg0];
	    int i_66_ = Class7.method97(-arg7 + arg3, Class126_Sub1.anInt3423,
					Class139.anInt2533, 65535);
	    int i_67_ = Class7.method97(arg7 + arg3, Class126_Sub1.anInt3423,
					Class139.anInt2533, arg4 ^ ~0xa2b8);
	    int i_68_ = Class7.method97(-i_39_ + arg3, Class126_Sub1.anInt3423,
					Class139.anInt2533, 65535);
	    int i_69_ = Class7.method97(i_39_ + arg3, Class126_Sub1.anInt3423,
					Class139.anInt2533, 65535);
	    Class67_Sub1_Sub11.method665(2, i_66_, is, i_68_, arg2);
	    Class67_Sub1_Sub11.method665(2, i_68_, is, i_69_, arg6);
	    Class67_Sub1_Sub11.method665(2, i_69_, is, i_67_, arg2);
	}
	int i_70_ = i_59_ * (-1 + i_40_);
	while (i > 0) {
	    boolean bool = (i_40_ ^ 0xffffffff) <= (i ^ 0xffffffff);
	    if ((i_51_ ^ 0xffffffff) > -1) {
		while (i_51_ < 0) {
		    i_51_ += i_57_;
		    i_57_ += i_58_;
		    i_37_++;
		    i_52_ += i_64_;
		    i_64_ += i_58_;
		}
	    }
	    if (i_52_ < 0) {
		i_51_ += i_57_;
		i_52_ += i_64_;
		i_64_ += i_58_;
		i_37_++;
		i_57_ += i_58_;
	    }
	    i_52_ += -i_60_;
	    if (bool) {
		if ((i_53_ ^ 0xffffffff) > -1) {
		    while ((i_53_ ^ 0xffffffff) > -1) {
			i_38_++;
			i_54_ += i_65_;
			i_65_ += i_56_;
			i_53_ += i_62_;
			i_62_ += i_56_;
		    }
		}
		if ((i_54_ ^ 0xffffffff) > -1) {
		    i_54_ += i_65_;
		    i_38_++;
		    i_65_ += i_56_;
		    i_53_ += i_62_;
		    i_62_ += i_56_;
		}
		i_53_ += -i_70_;
		i_54_ += -i_61_;
		i_61_ -= i_59_;
		i_70_ -= i_59_;
	    }
	    i_51_ += -i_63_;
	    i_60_ -= i_55_;
	    i--;
	    int i_71_ = arg0 - -i;
	    i_63_ -= i_55_;
	    int i_72_ = arg0 - i;
	    if ((i_71_ ^ 0xffffffff) <= (Class55_Sub2.anInt2801 ^ 0xffffffff)
		&& (i_72_ ^ 0xffffffff) >= (OutputStream_Sub1.anInt87
					    ^ 0xffffffff)) {
		int i_73_
		    = Class7.method97(arg3 - -i_37_, Class126_Sub1.anInt3423,
				      Class139.anInt2533, 65535);
		int i_74_
		    = Class7.method97(-i_37_ + arg3, Class126_Sub1.anInt3423,
				      Class139.anInt2533, 65535);
		if (bool) {
		    int i_75_ = Class7.method97(arg3 - -i_38_,
						Class126_Sub1.anInt3423,
						Class139.anInt2533, 65535);
		    int i_76_ = Class7.method97(-i_38_ + arg3,
						Class126_Sub1.anInt3423,
						Class139.anInt2533, 65535);
		    if (Class55_Sub2.anInt2801 <= i_72_) {
			int[] is = Class67_Sub29.anIntArrayArray3338[i_72_];
			Class67_Sub1_Sub11.method665(2, i_74_, is, i_76_,
						     arg2);
			Class67_Sub1_Sub11.method665(2, i_76_, is, i_75_,
						     arg6);
			Class67_Sub1_Sub11.method665(2, i_75_, is, i_73_,
						     arg2);
		    }
		    if ((OutputStream_Sub1.anInt87 ^ 0xffffffff)
			<= (i_71_ ^ 0xffffffff)) {
			int[] is = Class67_Sub29.anIntArrayArray3338[i_71_];
			Class67_Sub1_Sub11.method665(2, i_74_, is, i_76_,
						     arg2);
			Class67_Sub1_Sub11.method665(2, i_76_, is, i_75_,
						     arg6);
			Class67_Sub1_Sub11.method665(2, i_75_, is, i_73_,
						     arg2);
		    }
		} else {
		    if ((Class55_Sub2.anInt2801 ^ 0xffffffff)
			>= (i_72_ ^ 0xffffffff))
			Class67_Sub1_Sub11.method665(2, i_74_,
						     (Class67_Sub29
						      .anIntArrayArray3338
						      [i_72_]),
						     i_73_, arg2);
		    if ((i_71_ ^ 0xffffffff)
			>= (OutputStream_Sub1.anInt87 ^ 0xffffffff))
			Class67_Sub1_Sub11.method665(2, i_74_,
						     (Class67_Sub29
						      .anIntArrayArray3338
						      [i_71_]),
						     i_73_, arg2);
		}
	    }
	}
    }
    
    public static void method837(SignLink arg0, byte arg1) {
	Class93 class93 = null;
	anInt4477++;
	try {
	    if (arg1 != 88)
		aRSString_4467 = null;
	    Class31 class31 = arg0.method396("runescape", true);
	    while (class31.anInt706 == 0)
		Class67_Sub1_Sub23.method726(-108, 1L);
	    if (class31.anInt706 == 1) {
		class93 = (Class93) class31.anObject705;
		Stream Stream = Class25.method227(-6);
		class93.method1492(Stream.currentOffset,
				   Stream.buffer, 0, (byte) 127);
	    }
	} catch (Exception exception) {
	    /* empty */
	}
	do {
	    try {
		if (class93 == null)
		    break;
		class93.method1491(arg1 + -89);
	    } catch (Exception exception) {
		break;
	    }
	    break;
	} while (false);
    }
    
    public static void method838(byte arg0, int arg1, int arg2, int arg3,
				 int arg4) {
	int i = 0;
	anInt4479++;
	int i_77_ = arg2;
	int i_78_ = -arg2;
	if (arg0 < 58)
	    aRSString_4476 = null;
	int i_79_ = Class7.method97(arg3 + arg2, Class126_Sub1.anInt3423,
				    Class139.anInt2533, 65535);
	int i_80_ = -1;
	int i_81_ = Class7.method97(arg3 - arg2, Class126_Sub1.anInt3423,
				    Class139.anInt2533, 65535);
	Class67_Sub1_Sub11.method665(2, i_81_,
				     Class67_Sub29.anIntArrayArray3338[arg1],
				     i_79_, arg4);
	while ((i_77_ ^ 0xffffffff) < (i ^ 0xffffffff)) {
	    i_80_ += 2;
	    i_78_ += i_80_;
	    if ((i_78_ ^ 0xffffffff) < -1) {
		i_77_--;
		i_78_ -= i_77_ << 766683969;
		int i_82_ = i_77_ + arg1;
		int i_83_ = -i_77_ + arg1;
		if (i_82_ >= Class55_Sub2.anInt2801
		    && (i_83_ ^ 0xffffffff) >= (OutputStream_Sub1.anInt87
						^ 0xffffffff)) {
		    int i_84_
			= Class7.method97(i + arg3, Class126_Sub1.anInt3423,
					  Class139.anInt2533, 65535);
		    int i_85_
			= Class7.method97(arg3 + -i, Class126_Sub1.anInt3423,
					  Class139.anInt2533, 65535);
		    if (i_82_ <= OutputStream_Sub1.anInt87)
			Class67_Sub1_Sub11.method665(2, i_85_,
						     (Class67_Sub29
						      .anIntArrayArray3338
						      [i_82_]),
						     i_84_, arg4);
		    if (Class55_Sub2.anInt2801 <= i_83_)
			Class67_Sub1_Sub11.method665(2, i_85_,
						     (Class67_Sub29
						      .anIntArrayArray3338
						      [i_83_]),
						     i_84_, arg4);
		}
	    }
	    i++;
	    int i_86_ = arg1 - i;
	    int i_87_ = arg1 + i;
	    if (Class55_Sub2.anInt2801 <= i_87_
		&& ((OutputStream_Sub1.anInt87 ^ 0xffffffff)
		    <= (i_86_ ^ 0xffffffff))) {
		int i_88_
		    = Class7.method97(arg3 + i_77_, Class126_Sub1.anInt3423,
				      Class139.anInt2533, 65535);
		int i_89_
		    = Class7.method97(arg3 + -i_77_, Class126_Sub1.anInt3423,
				      Class139.anInt2533, 65535);
		if (OutputStream_Sub1.anInt87 >= i_87_)
		    Class67_Sub1_Sub11.method665(2, i_89_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_87_]),
						 i_88_, arg4);
		if (i_86_ >= Class55_Sub2.anInt2801)
		    Class67_Sub1_Sub11.method665(2, i_89_,
						 (Class67_Sub29
						  .anIntArrayArray3338[i_86_]),
						 i_88_, arg4);
	    }
	}
    }
    
    public static void method839(int arg0) {
	int i = 67 % ((33 - arg0) / 42);
	anInt4474++;
	Class131_Sub7_Sub2.aClass136_5073.method1922(0);
    }
    
    public static void method840(int arg0, RSString arg1) {
	anInt4466++;
	int i = Class67_Sub1_Sub39.method809(arg1, (byte) 119);
	if ((i ^ 0xffffffff) != 0) {
	    Class67_Sub1_Sub32.method767(-5402,
					 (Class68.aClass72_1369.aShortArray1443
					  [i]),
					 (Class68.aClass72_1369.aShortArray1444
					  [i]));
	    if (arg0 <= 102)
		aClass31_4475 = null;
	}
    }
    
    public Class67_Sub5_Sub2(Class131_Sub4 arg0) {
	aClass131_Sub4_4482 = arg0;
    }
    
    static {
	aBoolean4468 = true;
	anInt4472 = 0;
	aClass50ArrayArrayArray4471 = new Class50[4][104][104];
	aRSString_4476
	    = Class134.method1914("V-Brification des mises -9 jour )2 ",
				  (byte) 59);
	aRSString_4483 = Class134.method1914("welle2:", (byte) 99);
    }
}
