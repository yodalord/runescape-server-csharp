public class Class126_Sub3 extends Class126
{
    public static RSString aRSString_3444;
    public static RSString[] aRSStringArray3445 = new RSString[100];
    public static int anInt3446;
    public int anInt3447;
    public static int anInt3448;
    public int anInt3449;
    public static int anInt3450;
    public int anInt3451;
    public static int anInt3452;
    public static Class67_Sub24[][][] aClass67_Sub24ArrayArrayArray3453;
    public int anInt3454;
    public static RSString aRSString_3455;
    
    public static void method1720(boolean arg0) {
	if (arg0 != false)
	    aClass67_Sub24ArrayArrayArray3453 = null;
	aRSStringArray3445 = null;
	aRSString_3444 = null;
	aClass67_Sub24ArrayArrayArray3453 = null;
	aRSString_3455 = null;
    }
    
    public void method1712(byte arg0, int arg1, int arg2) {
	anInt3450++;
	int i = anInt3447 * arg1 >> 199740396;
	if (arg0 < -39) {
	    int i_0_ = anInt3449 * arg1 >> 1863143660;
	    int i_1_ = arg2 * anInt3454 >> 1151681132;
	    int i_2_ = arg2 * anInt3451 >> 1640441260;
	    Class34.method305(i, anInt2351, -30374, i_1_, i_2_, i_0_);
	}
    }
    
    public void method1708(byte arg0, int arg1, int arg2) {
	if (arg0 == -36)
	    anInt3446++;
    }
    
    public Class126_Sub3(int arg0, int arg1, int arg2, int arg3, int arg4,
			 int arg5) {
	super(-1, arg4, arg5);
	anInt3451 = arg3;
	anInt3454 = arg1;
	anInt3447 = arg2;
	anInt3449 = arg0;
    }
    
    public void method1710(int arg0, int arg1, byte arg2) {
	anInt3448++;
	if (arg2 != -67)
	    method1712((byte) -101, 40, 40);
    }
    
    static {
	aRSString_3444
	    = Class134.method1914("(U0a )2 non)2existant gosub script)2num: ",
				  (byte) 114);
	aRSString_3455
	    = (Class134.method1914
	       ("Votre liste d(Wamis est pleine (X100 noms maximum pour la version gratuite et 200 pour les abonn-Bs(Y)3",
		(byte) 35));
    }
}
