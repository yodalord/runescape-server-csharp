/* Interface2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface2
{
}
