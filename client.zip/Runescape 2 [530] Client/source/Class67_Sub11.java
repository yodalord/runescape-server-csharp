/* Class67_Sub11 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class67_Sub11 extends Class67
{
    public volatile boolean aBoolean3022 = true;
    public Class67_Sub13 aClass67_Sub13_3023;
    public Class67_Sub11 aClass67_Sub11_3024;
    public int anInt3025;
    
    public abstract Class67_Sub11 method1122();
    
    public abstract void method1123(int i);
    
    public abstract Class67_Sub11 method1124();
    
    public void method1125(int[] arg0, int arg1, int arg2) {
	if (aBoolean3022)
	    method1127(arg0, arg1, arg2);
	else
	    method1123(arg2);
    }
    
    public int method1126() {
	return 255;
    }
    
    public abstract void method1127(int[] is, int i, int i_0_);
    
    public abstract int method1128();
}
