/* Class61_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class61_Sub1 extends Class61
{
    public static int anInt2817;
    
    public static void method557(int arg0) {
	anInt2817 = arg0;
    }
    
    public static int method558() {
	return anInt2817;
    }
    
    public void method559() {
	/* empty */
    }
    
    public Class61_Sub1() {
	new Class90();
	new Class50();
    }
    
    static {
	new Class105(8);
	anInt2817 = 2;
	new Stream(131056);
    }
}
