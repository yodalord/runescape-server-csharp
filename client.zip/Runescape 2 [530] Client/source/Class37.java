public class Class37
{
    public static int anInt791 = -1;
    public static int anInt792;
    public static Class137 aClass137_793;
    public static int anInt794;
    public static int anInt795;
    public static int anInt796;
    public static int[] anIntArray797 = new int[4];
    public static boolean aBoolean798;
    public static int anInt799;
    public static int anInt800;
    public static int anInt801;
    public static RSString aRSString_802;
    public static int[] anIntArray803;
    public static RSString aRSString_804;
    public static RSString aRSString_805;
    
    public static void method319(int arg0, int arg1, int arg2, int arg3,
				 int arg4, int arg5, int arg6, int arg7,
				 int arg8) {
	if (arg8 != 22562)
	    aRSString_805 = null;
	anInt800++;
	if (!Class67_Sub5_Sub15.method977(arg7, false)) {
	    if ((arg5 ^ 0xffffffff) == 0) {
		for (int i = 0; (i ^ 0xffffffff) > -101; i++)
		    OutputStream_Sub1.aBooleanArray96[i] = true;
	    } else
		OutputStream_Sub1.aBooleanArray96[arg5] = true;
	} else
	    InputStream_Sub1.method51(arg1,
				      (Class67_Sub1_Sub5.aClass7ArrayArray3878
				       [arg7]),
				      -1, arg0, arg2, arg5, arg3, arg6, true,
				      arg4);
    }
    
    public static Class67_Sub5_Sub19_Sub1[] method320(int arg0) {
	if (arg0 != 17100)
	    return null;
	Class67_Sub5_Sub19_Sub1[] class67_sub5_sub19_sub1s
	    = new Class67_Sub5_Sub19_Sub1[Class67_Sub15.anInt3067];
	anInt792++;
	for (int i = 0;
	     (Class67_Sub15.anInt3067 ^ 0xffffffff) < (i ^ 0xffffffff); i++) {
	    byte[] is = Class67_Sub1_Sub35.aByteArrayArray4357[i];
	    int i_0_ = (Class67_Sub5_Sub4.anIntArray4510[i]
			* Class55_Sub3.anIntArray2810[i]);
	    int[] is_1_ = new int[i_0_];
	    for (int i_2_ = 0; i_2_ < i_0_; i_2_++)
		is_1_[i_2_]
		    = Class73.anIntArray1462[Class75.method1379(is[i_2_],
								255)];
	    class67_sub5_sub19_sub1s[i]
		= new Class67_Sub5_Sub19_Sub1(Class3.anInt119,
					      Class80.anInt1628,
					      Class67_Sub23.anIntArray3201[i],
					      Class67_Sub6.anIntArray2870[i],
					      Class55_Sub3.anIntArray2810[i],
					      (Class67_Sub5_Sub4.anIntArray4510
					       [i]),
					      is_1_);
	}
	Class67_Sub5_Sub11.method937(false);
	return class67_sub5_sub19_sub1s;
    }
    
    public static void method321(int arg0) {
	if (arg0 != 13548)
	    anInt791 = -38;
	if (Class81.aClass134_1648 != null) {
	    synchronized (Class81.aClass134_1648) {
		Class81.aClass134_1648 = null;
	    }
	}
	anInt799++;
    }
    
    public static void method322(int arg0) {
	if (arg0 == 1) {
	    anInt801++;
	    Class67_Sub1_Sub34.aClass136_4331.method1921((byte) -116);
	}
    }
    
    public static void method323(byte arg0) {
	aClass137_793 = null;
	aRSString_802 = null;
	aRSString_804 = null;
	anIntArray803 = null;
	int i = 49 % ((arg0 - -11) / 40);
	aRSString_805 = null;
	anIntArray797 = null;
    }
    
    public static void method324(int arg0, int arg1, int arg2, int arg3,
				 Class131 arg4, Class131 arg5, int arg6,
				 int arg7, int arg8, int arg9, long arg10) {
	if (arg4 != null) {
	    Class94 class94 = new Class94();
	    class94.aLong1886 = arg10;
	    class94.anInt1889 = arg1 * 128 + 64;
	    class94.anInt1887 = arg2 * 128 + 64;
	    class94.anInt1890 = arg3;
	    class94.aClass131_1894 = arg4;
	    class94.aClass131_1896 = arg5;
	    class94.anInt1898 = arg6;
	    class94.anInt1892 = arg7;
	    class94.anInt1893 = arg8;
	    class94.anInt1897 = arg9;
	    for (int i = arg0; i >= 0; i--) {
		if (Class76.aClass67_Sub24ArrayArrayArray1578[i][arg1][arg2]
		    == null)
		    Class76.aClass67_Sub24ArrayArrayArray1578[i][arg1][arg2]
			= new Class67_Sub24(i, arg1, arg2);
	    }
	    Class76.aClass67_Sub24ArrayArrayArray1578[arg0][arg1][arg2]
		.aClass94_3224
		= class94;
	}
    }
    
    public static void method325(int arg0) {
	Class67_Sub5_Sub6.aClass33_4557.method295((byte) 96);
	anInt796++;
	for (int i = 0; (i ^ 0xffffffff) > -33; i++)
	    Class67_Sub1_Sub1.aLongArray3821[i] = 0L;
	if (arg0 != 28028)
	    anIntArray803 = null;
	for (int i = 0; i < 32; i++)
	    Class124.aLongArray2325[i] = 0L;
	Class87.anInt1814 = 0;
    }
    
    public static void method326(Class7 arg0, int arg1) {
	if ((arg0.anInt204 ^ 0xffffffff)
	    == (Class67_Sub1_Sub37.anInt4399 ^ 0xffffffff))
	    OutputStream_Sub1.aBooleanArray96[arg0.anInt234] = true;
	anInt795++;
	if (arg1 <= 74)
	    method320(87);
    }
    
    static {
	anInt794 = 0;
	aBoolean798 = false;
	aClass137_793 = new Class137(64);
	aRSString_802 = Class134.method1914(",Mcran)2titre charg-B", (byte) 8);
	anIntArray803 = new int[256];
	aRSString_804 = Class134.method1914("compass", (byte) 66);
	aRSString_805 = Class134.method1914(":allyreq:", (byte) 41);
    }
}
