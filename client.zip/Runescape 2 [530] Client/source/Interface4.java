/* Interface4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface4
{
    public RSString method14(byte i, long l, int i_0_, int[] is);
}
