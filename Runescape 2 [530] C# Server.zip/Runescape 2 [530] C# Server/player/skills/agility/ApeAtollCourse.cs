﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RunescapeServer.player.skills.agility
{
    class ApeAtollCourse
    {
        public ApeAtollCourse()
        {
        }

        public static void doCourse(Player p, int objectX, int objectY, object[] objectArray)
        {
        }
    }
}
